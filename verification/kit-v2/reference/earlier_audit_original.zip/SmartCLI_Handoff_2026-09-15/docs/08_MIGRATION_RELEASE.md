# 08 · 兼容迁移与发布检查

## 不能破坏的既有能力

保留默认Python/pyte和POSIX+ConPTY；保留text hash与visual hash两种语义；保留DECCKM SS3适配、主/备屏、DSR/DA回答；保留经过真实参考终端验证的差分case与有意记录的profile分歧。保留registry认证/0600/0700和敏感控制变量保护；close不能因为timeout就删除活daemon唯一句柄。[SC03](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/pty_backend.py)；[SC04](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/session.py)；[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)；[SC13](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/references/LIMITATIONS.md)

## v1→v2建议

先新增协议版本与capabilities，不立即改全部命令。v1当前JSON和wait_ready保持兼容，由兼容层调用v2服务；新API使用typed envelope和明确的wait_idle/wait_command等。结构含session_generation/seq/geometry_epoch。旧selected保留但标注启发式；新格式允许候选和unknown。严格键名、脚本fail-on-timeout作为显式新模式，迁移期给warning，不把现有未知键字面输入行为突然改掉。

新增字段默认可忽略；字段含义变化升级协议。CLI退出码、MCP错误与Python异常映射有单独表和golden。长wait返回cancelled不是transport error，退出码与观察条件不满足分别记录。deprecated移除前有样例迁移与测试，不仅改README。

## 测试到发行

阶段一在源树验证，然后构建wheel在干净环境执行同契约；standalone skill验证vendor与canonical一致；不以本地editable安装成功代替wheel可安装。当前已有这些资产，重点是补关键runtime门禁和不隐藏first-pass失败。[SC10](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/.github/workflows/ci.yml)；[SC11](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tests/run_all.py)

最小依赖矩阵需要覆盖setuptools最低允许值、pyte capability分支和MCP允许范围。不因repo有意关闭Dependabot版本更新PR而擅自重开；保留人工/周期审查安全升级与锁文件差异的路径。当前HEAD的关闭设置属于用户已选择的维护方式。[SC02](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/pyproject.toml)；[SC17](https://api.github.com/repos/dwgx/SmartCLI/branches/main)；[STD02](https://setuptools.pypa.io/en/latest/userguide/pyproject_config.html)

## 文档源与版本

`NEXT-STEPS.md`应只有一块机器可查的current baseline，历史记录移附录。suite数量、effect/widget/recipe数量、版本10处一致性仍由现有门禁核验，避免再手写旧数。任何修改`smartcli_core`均同步独立skill中的vendor，运行sync/vendor/version/dependency/doc gates。不要因为“只改一行”跳过发布产物验证。[SC10](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/.github/workflows/ci.yml)；[SC11](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tests/run_all.py)；[SC12](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/NEXT-STEPS.md)

## 发布清单

| 检查 | 必须保留的证据 |
|---|---|
| P0关闭 | 最小repro、原版本失败、修复后通过、mutation或回退验证 |
| native平台 | 每OS适用case结果；未覆盖项和skip原因 |
| 安装入口 | wheel/sdist/skills内容清单；CLI/MCP握手与版本 |
| 权限/秘密 | 假密钥检查；annotations与策略；无token/环境秘密出包 |
| 依赖/许可 | 依赖锁、来源commit、适用license/notice、需要人工确认的项 |
| 记录与恢复 | 事件/快照对应seq；脱敏和重放限制说明 |
| 回滚 | 逐PR撤回路径；v1用户兼容；schema迁移说明 |
| 所有者授权 | push/tag/release之前明确取得用户指令 |

本交接包未执行这些发布动作。仓库明确排除的资料不应重新暴露；本包不包含私密反编译资料、不包含字体文件、不包含仓库秘密。
