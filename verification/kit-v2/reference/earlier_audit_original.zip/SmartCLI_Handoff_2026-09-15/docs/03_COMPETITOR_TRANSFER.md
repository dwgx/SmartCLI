# 03 · 竞品功能→代码→SmartCLI迁移表

本节不是“照抄清单”。S为实现读取，X为代码搜索片段，D为官方文档，P为上一轮资料。带P的条目不是本次重新源码审计；完整原58项目广度保留在corrected_atlas，本轮对最相关路线加深。

## microsoft/tui-test
**已核对的设计。** LiveFrame携带keyboard/mouse/bracketed-paste/exited；独立Operation/timeout类
**SmartCLI的落点。** 提取TerminalFrame与类型化操作服务，明确idle/ready/command/exit；可取消控制面（T13,T16,T21,T23）。
**不要照搬。** 它的engine.execute也有operations锁；不要说复制它就自动得到多waiter并发。多引擎beta不是所有后端完全等价。
来源：[CP01](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/crates/tui-test/src/engine.rs)；[CP03](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/SKILL.md)

## coder/agent-tty
**已核对的设计。** eventLog schema、单调seq、append失败传播、输入/输出/resize/exit多事件
**SmartCLI的落点。** 写入journal+checkpoint，关联截图与确切seq；失败导出可审查bundle（T24,T25,T26）。
**不要照搬。** 先定义磁盘满、敏感数据、持久化失败；不能直接把几十万事件缓冲上限复制成SmartCLI合理预算。PNG不是实际宿主像素。
来源：[CP06](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/src/host/eventLog.ts)；[CP07](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/README.md)

## onesuper/tui-use
**已核对的设计。** xterm事件订阅、scrollback、按cell宽度重编码style
**SmartCLI的落点。** 持续drain、region/diff、缓存观察；把样式事实单独返回（T07,T20,T22）。
**不要照搬。** highlights只inverse且其字符串索引也需检查；KEY_MAP固定CSI不是SmartCLI已有SS3适配的替代。别把对方所有代码都当正确模板。
来源：[CP09](https://github.com/onesuper/tui-use/blob/main/src/session.ts)；[CP10](https://github.com/onesuper/tui-use/blob/main/src/highlights.ts)

## bnomei/tmux-mcp
**已核对的设计。** tracked command结果含status/exit_code；private exit-code buffer与清理
**SmartCLI的落点。** 对shell可选hook或可信旁路，command_id与独立退出状态（T11,T16）。
**不要照搬。** 只能在支持边界的shell保证command verdict；不能往Vim buffer注入shell wrapper。秘密buffer也要在对应威胁模型下审查。
来源：[CP12](https://github.com/bnomei/tmux-mcp/blob/c4762ea36b1a288a95ba5cc125154fae65a60ad5/src/tmux.rs)；[CP13](https://github.com/bnomei/tmux-mcp/blob/c4762ea36b1a288a95ba5cc125154fae65a60ad5/src/commands.rs)；[CP14](https://github.com/bnomei/tmux-mcp/blob/c4762ea36b1a288a95ba5cc125154fae65a60ad5/src/types.rs)

## pi-interactive-shell
**已核对的设计。** takeover与exited分离；monitor/dispatch有notification与budget
**SmartCLI的落点。** 手动接管fencing，通知输出尾部与预算；监督结束≠进程死亡（T15,T27,T33）。
**不要照搬。** Pi triggerTurn机制不能直接照搬任意MCP；quiet auto-close不是命令成功，README已强调。
来源：[CP15](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/README.md)；[CP16](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/overlay-component.ts)；[CP17](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/index.ts)

## taria
**已核对的设计。** input_id、ack、应用widget tree与输入ignored/applied状态
**SmartCLI的落点。** SemanticProvider，先适配tui-ui，再可选taria bridge；ACK只能应用确认（T28,T29）。
**不要照搬。** Unix prealpha、单bridge限制；应用提供的语义仍是不可信内容；不能替未改造TUI生成假ACK。
来源：[CP18](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/README.md)；[CP19](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/crates/taria-mcp/src/bridge.rs)；[CP20](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/crates/taria-mcp/src/server.rs)

## mcp-tui-driver
**已核对的设计。** 文档列出mouse/modifiers/PNG/asciicast/脚本
**SmartCLI的落点。** 完善丰富输入、assert脚本和artifact surface（T17,T21,T25）。
**不要照搬。** 本轮没有深审它的实现，按D证据看功能；accessibility-style不等于真实widget tree。
来源：[CP21](https://github.com/michaellee8/mcp-tui-driver/blob/main/README.md)

## Ellery terminal-mcp
**已核对的设计。** 共享终端host/client，text/ANSI/PNG多观察通道
**SmartCLI的落点。** readonly attach起步，需要视觉时再请求图像（T25,T27）。
**不要照搬。** 本轮继承上轮官方资料未重审；渲染截图与真实窗口截图要区分。
来源：[CP22](https://github.com/elleryfamilia/terminal-mcp/blob/main/README.md)

## TST / mcp-server-terminal
**已核对的设计。** 从屏幕提取可操作树的路线
**SmartCLI的落点。** 允许可替换推断插件，与app-published语义分层（T18,T28）。
**不要照搬。** 只当推断，不保证节点ID稳定或可点击；本轮未重新审其源码。
来源：[CP23](https://github.com/aybelatchane/mcp-server-terminal/blob/main/README.md)

## nvim-mcp / Textual Pilot路线
**已核对的设计。** 应用RPC/框架内状态比屏幕含有更多信息
**SmartCLI的落点。** 编辑器模式、buffer、应用焦点的可选适配（T29）。
**不要照搬。** 适配赛道与严格键盘赛道必须分开；不能用RPC改文件通过Vim操作测评。
来源：[CP24](https://github.com/InfJoker/nvim-mcp/blob/main/README.md)

## nvms/tui-mcp / forge
**已核对的设计。** 区域读与每消费者独立cursor
**SmartCLI的落点。** since_seq、region、reader_id；一次渲染多订阅（T20）。
**不要照搬。** 上轮资料，不以此声称它们没有并发缺陷。reader cursor不等同输入权限。
来源：[CP25](https://github.com/nvms/tui-mcp/blob/main/README.md)；[CP26](https://github.com/ferodrigop/forge/blob/main/README.md)

## SmartCLI自有截图/艺术/UI资产
**已核对的设计。** pyte→PNG、尺寸矩阵、感知case、跨主题widgets
**SmartCLI的落点。** 优先复用，减少新依赖；从tui-ui发布semantics并构造adversarial fixtures（T18,T25,T28,T32）。
**不要照搬。** 不要新建重复截图库；reference PNG无法证明模拟器与真实终端一致。
来源：[SC14](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/shot.py)；[SC15](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/cli.py)；[SC16](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/perception_matrix.py)

## 许可证与代码复用

本包只交付分析、原项目所有者代码的极小逻辑缩减，以及新写的测试/设计；没有复制整个竞品实现。真正移植时，对每个目标commit核对LICENSE/NOTICE与依赖许可。使用Apache代码进入MIT主体时需保留其适用许可与NOTICE要求，不能把复制代码全部重新标成MIT；这是发布清单要求，不替代正式许可审查。当前建议优先迁移API思想与测试不变量，自写适配。
