# 05 · 架构决策记录（建议，不是已实现能力）

## ADR-01：单一模型拥有者，但观察者不是单一

保留PtySession/pyte只有一个线程或事件循环更新的约束。当前visual_hash会消费dirty集合，pump会读→解析→回设备响应，resize跨多个字段更新；直接加线程并发调用会破坏状态。需要替换的不是这个约束，而是“把长wait当一个阻塞RPC”的调度模型。[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)

```text
CLI / Python / MCP
       │ request + deadline + capability + expected_seq
       ▼
认证/准入 + 有界请求队列
       ▼
Session OwnerLoop ───► Frame revisions / Watchers / Input receipts
  │   ▲                        │                  │
  │   └── bounded PTY output   └── immutable response ─► socket writers
  ├── Input queue ─► PTY
  ├── terminal engine + mode/profile
  └── ordered event journal ─► replay / snapshots / PNG / read-only viewer
```

Owner每tick最多处理指定字节数和时间预算；不同来源交替服务，不无界drain。CPU预算被耗尽时让出循环，下个tick续接。准入前有连接/请求大小/速率限制；出站缓冲有每连接上限；日志/scrollback有高水位。达到限制时返回busy/degraded/resync_required，而不是声称成功却丢信息。初始调参必须从工作负载测量取得，本包不把任意固定64或4MiB当最佳值。

Watch是独立对象：`watch_id, predicate, after_seq, deadline, cancellation`。一个屏幕可以同时满足正则、退出、区域变化三种不同谓词；这不需要多线程进入model。close/cancel优先调度，但teardown仍由owner执行。禁止从read-only watcher偷偷递归进入另一个wait。

## ADR-02：哈希、序号、因果、验收是四件事

保留现有content_hash和visual_hash，两者用途正确不同，不要把text hash升级后破坏blink忽略策略。增加事件序号seq、screen_revision、geometry_epoch、session_generation，分别应对重复画面、尺寸变化和重启。CRC用于快速比较，不能作为身份凭证或防篡改证据。[SC04](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/session.py)；[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)；[CP06](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/src/host/eventLog.ts)

`act_and_observe`应在一个owner临界序列内检查预期revision/lease、登记action、提交输入、建立watch，避免“先截图、很久后按键”的陈旧坐标。但**顺序相关不是语义因果证明**：动作之后发生动画变化不代表动作被接受。返回至少四个层次：

| 层次 | 可以陈述什么 | 不可以陈述什么 |
|---|---|---|
| accepted | 请求通过验证并入队 | 输入已经到程序 |
| written | PTY写入字节完成 | Vim已执行命令 |
| observed | 某个后续revision满足观察谓词 | 状态变化一定由本动作造成 |
| applied | 应用适配器提供匹配action_id的ACK | 业务任务最终正确 |
| verified | 独立裁判验证结果 | 所有未来场景都会正确 |

默认通用黑盒终端没有应用ACK，applied必须为unknown，而不是true。即使同一writer独占，目标程序还可能有后台状态变化。独立验收可以验证文件内容、退出码或外部fixture状态，但严格UI评测不允许用该裁判直接修改任务。

## ADR-03：事实、启发式、应用语义分离

保留按cell的事实层：glyph/width/style/cursor/mode/buffer。高亮并非选中，红色并非错误，末行并非提示符。推断层独立输出候选和来源，例如`inferred.highlight-run`、`inferred.cursor-line`，可用low/medium/high等级，只有校准数据足够时才使用看似精确的0.93概率。应用层声明`app-provided`且附适配器与revision，但应用提供的数据同样不能绕过安全策略。[SC06](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/snapshot.py)；[CP10](https://github.com/onesuper/tui-use/blob/main/src/highlights.ts)；[CP18](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/README.md)

v2应允许selected=null，允许多候选，不用最宽span强行定一个答案。向后兼容时保留v1字段但标注deprecated，不静默把旧selected从单值变数组。把col_start/col_end定义为**终端cell坐标，end exclusive**；文本从cells聚合，不从Unicode字符串下标推导。对切在宽字continuation上的region明确clip/expand策略，并输出调整后的实际区域。

错误检测应拆为观察信号（red/keyword）与执行事实（exit!=0/应用error ACK）；把`0 errors`计为失败属于分类错误。数据集要同时统计false positive、false negative、abstain，不仅看几个成功截图。

## ADR-04：稳定的TerminalEngine契约优先于一次性换引擎

接口建议包括feed(bytes)、frame()、resize(size)、modes()、drain_replies()、diagnostics()。pyte是默认实现，既有经过差分锁定的修订保留；可加xterm/Ghostty实验后端作为对照而非立即替换。所有backend输出同一Cell/Frame协议，但宽度profile与不支持特性不可隐藏。[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)；[CP01](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/crates/tui-test/src/engine.rs)；[CP09](https://github.com/onesuper/tui-use/blob/main/src/session.ts)

需固定的profile元数据：TERM/terminfo假设、Unicode宽度版本与ambiguous width、grapheme策略、alternate screen行为、SGR支持、应用键/鼠标模式。只支持部分VT时不能伪称支持完整xterm。DSR/DA应由能力配置回答，不向应用广告未实现协议。对终端间有真实差异的IL/DL/resize，保存多个合法profile golden，不以多数票覆盖全部目标。

验收顺序：纯状态机分片不变性→模拟器差分→真实目标TUI→跨OS native→Agent任务。模拟器截图看起来正确不能替代与真实终端比对。

## ADR-05：类型化应用服务，CLI/MCP做薄适配

目前MCP部分功能经subprocess调用CLI，其余复用_call，保持了认证一致性，但也继承SystemExit和字符串JSON。v2把生命周期/观察/输入变成一个type-checked应用服务；CLI负责格式化与退出码，MCP负责schema/annotations/资源引用，Python库直接消费同一对象。不能另建一套功能稍不同的MCP runtime。[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)；[SC09](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/mcp_server.py)

错误码至少区分：invalid_request、unauthorized、busy、stale_observation、lease_lost、unsupported、timeout、cancelled、process_exited、io_error、perception_degraded、artifact_failed。`ok`是调用是否按契约执行，不是用户目标成功。长返回值用资源URI或显式full/region/diff选项，文本和结构不要每次都无差别重复。

## ADR-06：权限不依赖终端文本或工具提示

控制面认证已有能力token，继续保留常量时间验证、权限目录、环境保留变量防护。新设计把read/write/admin能力分离；writer lease不是新增操作系统隔离，而是避免合法调用者之间串键。与同UID不可信子进程共享文件权限时，0600不是隔离该子进程的边界。默认运行任意命令必须如实标成宿主权限。[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)；[SC09](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/mcp_server.py)；[STD03](https://modelcontextprotocol.io/specification/2026-07-28/schema)

MCP annotations按潜在作用保守描述，不把send_line写成只会追加数据。屏幕可能展示恶意指令、文件里的提示注入、凭证，必须作为不可信观察而不是新的系统指令；拒绝策略仍在Harness/权限执行层。仅仅转义、加标签或提示词不构成完美防注入。

secret_ref经授权配置/受限通道解析，避免在CLI argv中出现秘密值。日志、截图、MCP返回都需要保留策略；原始字节与脱敏记录若同时保留，应分开权限并在manifest声明。默认不要把所有输入永久记录。若redaction改变重放屏幕，应明确“脱敏重放不保证像素一致”。

## ADR-07：证据是版本化事件，不是随手多截一张图

事件记录input/output/resize/signal/exit/marker、seq与单调时间、engine/profile。checkpoint保存重放必要状态，逻辑快照只能复现视觉观察而不能恢复真实子进程执行。将“重放观察”“重新执行任务”“恢复活进程”分成三个命令/状态，禁止混用。[CP06](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/src/host/eventLog.ts)；[CP07](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/README.md)；[SC14](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/shot.py)

优先复用`tools/screenshot`从同一immutable frame生成PNG；导出必须带frame_seq、字体/宽度profile标识、渲染器版本。不要把PNG说成本机窗口截图。视频后做，先完成文本/JSON/PNG/cast的可验证闭环。错误日志不能静默忽略write失败；存储满时会话可继续与否由策略决定，并显式recording_degraded。

proof bundle建议包含manifest、协议版本、源码SHA、环境摘要、操作journal、前后frame、可选PNG、断言输入和结果，以及失败分类。不要包含secret值、控制token、私有资料、字体文件或仓库明确排除的目录。

## ADR-08：人机共享是权限状态机，不是把stdin广播给所有人

先做read-only attach，让人看Agent正在看的确切seq。再做显式takeover/release：人类输入前获得新fencing token；Agent旧token即使延迟到达也被拒绝。掉线不一定终止子进程，lease到期与process exit独立；会话保留策略、detached继续、监督取消各自清楚。Pi是交接状态与通知设计的参考，不要求引入其整个宿主。[CP15](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/README.md)；[CP16](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/overlay-component.ts)；[CP17](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/index.ts)

## ADR-09：语义适配保持可选，并把评测赛道分开

先用自身tui-ui证明widget tree/action ACK；然后Neovim RPC、Textual Pilot风格、taria bridge按需求添加。semantic action失败时回退到通用键盘并重新观察，不伪造selected。由于适配器得到额外信息，基准必须单列；通用黑盒分数不能偷偷吃到RPC/LSP/文件API的优势。[CP18](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/README.md)；[CP19](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/crates/taria-mcp/src/bridge.rs)；[CP24](https://github.com/InfJoker/nvim-mcp/blob/main/README.md)
