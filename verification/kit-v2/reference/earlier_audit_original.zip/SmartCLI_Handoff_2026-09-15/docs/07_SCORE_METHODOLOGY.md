# 07 · 评分方法与逐维依据

## 定义

这是人工的**功能覆盖/接口产品化盘点**，不是性能跑分、可靠性概率、市场排名或审计认证。SmartCLI的缺陷另列A01–A20，不能因功能覆盖65分就认为65%任务能成功。反过来，修完P0未必提高覆盖分，但很可能比新增功能更重要。

0=已审查工具面无该能力；1=零散工具/人工拼装；2=基础路径；3=覆盖主要场景；4=较完整并有相关契约/资产；5=该维度的深度产品化接口。分值按已读取材料的工程判断，不是自动测量。

未知U/空白不等于0。跨产品总表中，区间下界为已知维度的加权贡献，上界假设未知维度全为5；这是**未知信息范围**，不是统计置信区间。已知归一分可用于局部比较，但只覆盖已知权重，不能拿它排总榜。

所有产品都做了局部而非完全审计；SmartCLI读得更深，已知缺陷更多属于审查深度不对称。因此总表只比较功能面，不单独设一个臆测的“可靠性胜率”。验证维度评分表示资产与契约存在，绝不表示当前CI已绿。

## 权重

| 维度 | 权重 |
|---|---:|
| 原生跨平台/无tmux依赖 | 15% |
| 屏幕与观测表达 | 20% |
| 键鼠/粘贴输入 | 10% |
| 等待与完成语义 | 15% |
| 录制/回放/可审阅证据 | 10% |
| 人机共享/控制交接 | 10% |
| 库/CLI/MCP/发行接入 | 10% |
| 验证资产与发布契约 | 10% |

公式：已知贡献 = Σ(权重 × 分数 / 5)；已知权重 = Σ有分维度权重；下界=已知贡献；上界=下界+未知权重。工作簿通过公式自动重算；更改权重应保持合计100，否则说明页告警。

## 产品汇总

| 产品 | 已知权重 | 功能覆盖分/区间 | 证据 |
|---|---:|---:|---|
| SmartCLI | 100% | 65 | S+D |
| microsoft/tui-test | 100% | 84 | S+X+D |
| coder/agent-tty | 100% | 72 | S+D |
| onesuper/tui-use | 100% | 52 | S+D |
| bnomei/tmux-mcp | 90% | 54–64 | X+P |
| pi-interactive-shell | 90% | 61–71 | D+X |
| mcp-tui-driver | 65% | 43–78 | D |

未对taria、TST、Neovim RPC和Textual做通用终端总分，因为需要应用改造/服务不同输入域，强行放进同一总分会误导。它们在功能迁移表中作为专项参照。

## SmartCLI建议目标

优先G1/G2修可靠性，覆盖分仍可保持65。完成G3–G5后可按同一尺度重新打分；若平台4、观察4、输入4、等待4、证据4、共享4、接入5、验证5，则规划覆盖目标为84。该数字只表示计划中的功能覆盖，不是承诺性能等于/超过Microsoft，也不证明任务成功率。

## SmartCLI
当前65分是覆盖度，不扣除下表每项缺陷；真实性/性能未排名。

| 维度 | 分值 | 理由 |
|---|---:|---|
| 原生跨平台/无tmux依赖 | 4 | Winpty+POSIX且三OSCI；ConPTY信号限制仍在 |
| 屏幕与观测表达 | 4 | 真实pyte cells、选中/错误提示与双hash；推断并非原生语义 |
| 键鼠/粘贴输入 | 2 | F1–F12/SS3已有；鼠标、粘贴协议缺 |
| 等待与完成语义 | 3 | 多种marker/stable/change；无command/exit完整结果 |
| 录制/回放/可审阅证据 | 2 | 已有码库PNG；持续会话journal/export尚未统一 |
| 人机共享/控制交接 | 1 | 多调用方socket可读写，但无正式attach/lease |
| 库/CLI/MCP/发行接入 | 5 | Python库+pipwheel+CLI+stdioMCP+skills |
| 验证资产与发布契约 | 4 | 多矩阵、fuzz、差分、wheel契约；非当前绿灯证明 |

来源：[SC02](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/pyproject.toml)；[SC03](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/pty_backend.py)；[SC04](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/session.py)；[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)；[SC06](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/snapshot.py)；[SC07](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/readiness.py)；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)；[SC09](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/mcp_server.py)；[SC10](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/.github/workflows/ci.yml)；[SC14](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/shot.py)

## microsoft/tui-test
当前beta；多后端/多语言较广。live状态不等于完整多写者租约。

| 维度 | 分值 | 理由 |
|---|---:|---|
| 原生跨平台/无tmux依赖 | 4 | 官方跨平台面，beta各后端仍需验证 |
| 屏幕与观测表达 | 4 | cells/styles/locator和多backend |
| 键鼠/粘贴输入 | 5 | keyboard mode、paste、mouse明确工具面 |
| 等待与完成语义 | 4 | 四类等待明确；仍非任务语义证明 |
| 录制/回放/可审阅证据 | 5 | 截图/自动录制与失败artifact |
| 人机共享/控制交接 | 3 | LiveFrame/交互查看；非任意多写者保证 |
| 库/CLI/MCP/发行接入 | 5 | Rust/Python/JS库与CLI，接入面广 |
| 验证资产与发布契约 | 4 | runtime测试与beta发布资料存在 |

来源：[CP01](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/crates/tui-test/src/engine.rs)；[CP02](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/bindings/js/src/client.ts)；[CP03](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/SKILL.md)；[CP04](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/README.md)；[CP05](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/crates/tui-test/tests/runtime.rs)

## coder/agent-tty
证据链强；Windows二级；run非子命令结构化结果。

| 维度 | 分值 | 理由 |
|---|---:|---|
| 原生跨平台/无tmux依赖 | 3 | Linux/mac一级，Windows二级未CI |
| 屏幕与观测表达 | 4 | Ghostty snapshot与reference PNG |
| 键鼠/粘贴输入 | 4 | type/paste/sendkeys/resize/signal；不称任意协议齐全 |
| 等待与完成语义 | 3 | scope等待与stable；run退出码边界 |
| 录制/回放/可审阅证据 | 5 | 序列日志、schema与PNG/cast/WebM |
| 人机共享/控制交接 | 2 | readonly dashboard；非human writable接管主线 |
| 库/CLI/MCP/发行接入 | 4 | CLI JSON+skill，多工具可调用 |
| 验证资产与发布契约 | 4 | dogfood/repro/事件契约存在 |

来源：[CP06](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/src/host/eventLog.ts)；[CP07](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/README.md)；[CP08](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/docs/USAGE.md)

## onesuper/tui-use
headless事件+scrollback、轻量CLI；highlight/按键边界需测。

| 维度 | 分值 | 理由 |
|---|---:|---|
| 原生跨平台/无tmux依赖 | 3 | nodepty跨平台路径，shell启动兼容待测 |
| 屏幕与观测表达 | 3 | xtermgrid/scrollback/title/fullscreen，高亮仅inverse |
| 键鼠/粘贴输入 | 2 | 固定key表，未见与SmartCLI等价SS3切换 |
| 等待与完成语义 | 3 | 事件wait与changed；command boundary有限 |
| 录制/回放/可审阅证据 | 1 | 主要snapshot，未证实统一持久artifact |
| 人机共享/控制交接 | 1 | daemon会话控制，无正式handoff |
| 库/CLI/MCP/发行接入 | 4 | CLI/plugin易接入 |
| 验证资产与发布契约 | 3 | 源码测试文件存在，未跑 |

来源：[CP09](https://github.com/onesuper/tui-use/blob/main/src/session.ts)；[CP10](https://github.com/onesuper/tui-use/blob/main/src/highlights.ts)；[CP11](https://github.com/onesuper/tui-use/blob/main/README.md)

## bnomei/tmux-mcp
依赖tmux；共享得分是宿主attach能力，非已验证租约；测试维度未知。

| 维度 | 分值 | 理由 |
|---|---:|---|
| 原生跨平台/无tmux依赖 | 2 | tmux依赖，对原生Windows覆盖较弱 |
| 屏幕与观测表达 | 3 | capturepane含样式，非原生widgettree |
| 键鼠/粘贴输入 | 3 | tmux发送键，rich input依赖宿主 |
| 等待与完成语义 | 4 | 执行状态、私有exitbuffer而非猜提示符 |
| 录制/回放/可审阅证据 | 1 | 抓屏为主，缺已核对可回放证据面 |
| 人机共享/控制交接 | 4 | tmux原生attach可共享；writer隔离未知 |
| 库/CLI/MCP/发行接入 | 4 | MCP typed command/result |
| 验证资产与发布契约 | U | 本轮未审CI，不评分 |

来源：[CP12](https://github.com/bnomei/tmux-mcp/blob/c4762ea36b1a288a95ba5cc125154fae65a60ad5/src/tmux.rs)；[CP13](https://github.com/bnomei/tmux-mcp/blob/c4762ea36b1a288a95ba5cc125154fae65a60ad5/src/commands.rs)；[CP14](https://github.com/bnomei/tmux-mcp/blob/c4762ea36b1a288a95ba5cc125154fae65a60ad5/src/types.rs)

## pi-interactive-shell
人机交接突出，但Pi耦合；quiet completion不是command verdict。

| 维度 | 分值 | 理由 |
|---|---:|---|
| 原生跨平台/无tmux依赖 | 3 | zigpty预构建说明；native各OS本次未测 |
| 屏幕与观测表达 | 3 | 实时屏幕/日志视图，语义较薄 |
| 键鼠/粘贴输入 | 4 | inputKeys/输入/用户键盘 |
| 等待与完成语义 | 4 | 返回session、通知、monitor与completionReason |
| 录制/回放/可审阅证据 | 2 | 输出tail与事件历史，非确定VT重放 |
| 人机共享/控制交接 | 5 | 明确human takeover与返还控制 |
| 库/CLI/MCP/发行接入 | 3 | Pi extension，对其他harness需adapter |
| 验证资产与发布契约 | U | 本轮未审CI，不评分 |

来源：[CP15](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/README.md)；[CP16](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/overlay-component.ts)；[CP17](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/index.ts)

## mcp-tui-driver
只按已读官方工具面评分；平台/共享/测试不补猜分。

| 维度 | 分值 | 理由 |
|---|---:|---|
| 原生跨平台/无tmux依赖 | U | 未知，不以配置路径推断支持 |
| 屏幕与观测表达 | 3 | 文档screen+accessibility-style；不是app DOM |
| 键鼠/粘贴输入 | 4 | mouse click/modifiers/text |
| 等待与完成语义 | 3 | text/idle/session管理 |
| 录制/回放/可审阅证据 | 4 | PNG+asciicast记录 |
| 人机共享/控制交接 | U | 本轮未知 |
| 库/CLI/MCP/发行接入 | 3 | MCP与cargo源码安装 |
| 验证资产与发布契约 | U | 本轮未知 |

来源：[CP21](https://github.com/michaellee8/mcp-tui-driver/blob/main/README.md)
