# 06 · 统一验收与基准计划

## 测什么，而不是怎样获得漂亮分数

本包未产生任何跨产品速度、准确率、token节省的实验结果。覆盖分只是工程盘点。要证明SmartCLI优于某方案，需要同模型、同任务、同接口权限、同环境与同预算，并让独立裁判验证目标。已有Harbor/Terminal-bench适配测试可复用，但源码中存在adapter不等于完成一次正式评测。[SC10](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/.github/workflows/ci.yml)；[SC11](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tests/run_all.py)；[CP05](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/crates/tui-test/tests/runtime.rs)

### 三个必须分开的赛道

A．**严格UI**：Agent只能snapshot/keys/type/paste/mouse/wait；不能读写任务文件、用sed/脚本改Vim文件，也不能调用应用RPC。裁判可以在外部读最终文件或状态，但不向Agent泄漏答案。

B．**应用适配**：允许Neovim/Textual/taria等明确列出的结构接口。报告适配器实现成本和覆盖比例，不混入A。

C．**混合任务效率**：允许文件API、shell命令与直接业务API，目标是工作完成。适合衡量实际生产率，但不能宣传为“像人类一样操作TUI”的能力。

### 固定变量

固定OS镜像、CPU/内存、Python/Node/Rust版本、依赖锁、终端引擎、TERM、locale、字体标识、Unicode宽度profile、目标应用版本、屏幕尺寸、时间预算、模型精确版本、提示词、重试策略。所有工具adapter暴露同等动作集；不支持的功能标unsupported，不给某工具额外人工指导。模型和API随时间变化时必须重验并保存配置。

初始可用80×24、160×50、300×100三个几何；中英日、combining与emoji语料；Linux/macOS/Windows各有native smoke。尺寸和场景是建议的测试设计，不是声称已经跑过的样本。

### 结果与统计

每case至少保存一次原始失败；研究阶段按预注册重复次数与seed运行。输出success、first-pass、retries、timeouts、unknown、unsupported、skip，不把unknown算success。对成功率报告二项置信区间，对延迟/成本报告样本量、median、p95及合适的bootstrap区间；不要仅选最快一次。不同环境p95不能直接相减。

记录TTFO（首个可用观察）、action-to-observation、cancel latency、peak RSS、CPU、磁盘、token、tool calls、输入丢失/重复率、状态误确认率、fidelity降级率、selected误检率、人类接管恢复成功率。启动成本与持续会话成本分开。parser和Python调用微基准不能取代真实应用任务成功率。

### 建议发布门（目标，不是测量值）

无未处理P0；确定性数据保真测试应全部通过；native smoke无未解释失败；限额/取消有明确上界；历史回归不倒退；安装后与源树行为一致；所有性能改变给实测分布。不要将某台机器绝对毫秒数写成所有平台SLA。需要SLA时先定义资源配额与目标工作负载，再由基线决定阈值。

## 20组场景

### B01 · 所有字节分片
输入：ANSI/SGR/UTF8随机切块。
验收/指标：cells+cursor+attrs一致。
对应任务：T04,T32。

### B02 · 多语言选择
输入：中文/日文/combining/emoji前缀菜单。
验收/指标：cell范围和selected.text一致。
对应任务：T05,T18。

### B03 · 主题误检
输入：全背景/粗体header/红色说明。
验收/指标：误检率、拒判率、召回。
对应任务：T18。

### B04 · 输入短写
输入：short write/EAGAIN/EINTR。
验收/指标：接收字节等于发送，无重复。
对应任务：T03。

### B05 · Vim严格UI
输入：进入模式、修改、撤销、保存、退出。
验收/指标：独立文件检查+键程记录。
对应任务：T21,T31。

### B06 · 后台无轮询
输入：大输出+CPR设备问询。
验收/指标：持续进展/队列有界。
对应任务：T07。

### B07 · 旧prompt与动画
输入：同marker留屏、其他writer/动画。
验收/指标：不误报本动作完成。
对应任务：T14,T16。

### B08 · 并发watcher
输入：三predicate+取消+人工查看。
验收/指标：各deadline独立、无模型并发。
对应任务：T10。

### B09 · 慢连接/慢读
输入：小cap本地fake socket负载。
验收/指标：reader/queue/RSS与延迟预算。
对应任务：T08,T09。

### B10 · 进程生命周期
输入：exit7/execfail/child+grandchild。
验收/指标：缓存status、不留受控子孙。
对应任务：T11,T12。

### B11 · 全屏/resize
输入：shell→less→Vim→shell并调整宽高。
验收/指标：alt/主屏/坐标代际正确。
对应任务：T23。

### B12 · 键鼠/粘贴
输入：DECCKM/BracketedPaste/SGRmouse。
验收/指标：目标实际事件一致。
对应任务：T21。

### B13 · 回放证据
输入：input/output/resize/checkpoint+diskfull。
验收/指标：同profile重放一致/降级可见。
对应任务：T24,T26。

### B14 · 共享控制
输入：人接管、租约过期、旧writer重试。
验收/指标：fencing阻止串键。
对应任务：T15,T27。

### B15 · 秘密与注入
输入：fake密钥/恶意终端说明。
验收/指标：凭证不出argv/日志，策略不越权。
对应任务：T19。

### B16 · 三发行面
输入：source/wheel/standalone skills。
验收/指标：同版本协议及vendor哈希。
对应任务：T34,T37。

### B17 · 语义适配
输入：同UI黑盒vsapp发布tree。
验收/指标：ACK边界、动作/结果可比。
对应任务：T28,T29。

### B18 · 观测成本
输入：80x24/160x50/300x100，多reader。
验收/指标：calls/tokens/CPU/RSS/latency实测。
对应任务：T20,T33。

### B19 · 远程恢复
输入：SSH断线/客户端重连。
验收/指标：unknown≠success，重连不假造进程。
对应任务：T30。

### B20 · 脚本退出码
输入：wait超时/断言失败/正常完成。
验收/指标：非零/错误原因稳定。
对应任务：T17。

## 对故障注入的边界

线程/连接上限使用fake socket或隔离本机小cap进行验证，不对用户在线服务或第三方目标压测。真实PTY每个fixture在finally清理，限制并发与输出，记录退出证据。被测进程可能派生后代，不能只看registry数量等于0就宣称没有泄漏。

## 基准数据结构

每次run保存：run_id、repo_sha、tool_name/version/backend、track、fixture_id、seed、model_id、host_profile、budgets、start/end单调时间、actions、observations、receipts、artifact_manifest、verdict、failure_taxonomy、tokens/calls/resources、first_pass/retry_count/skip_reason。交付的benchmarks.json是情景清单，不是实验数据。
