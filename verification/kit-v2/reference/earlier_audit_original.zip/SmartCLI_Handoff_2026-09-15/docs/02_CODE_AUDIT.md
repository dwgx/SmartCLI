# 02 · 逐项源码审计

基线 `701e61f6d69aa2420617edf80b1136df8d5e8cf7`。P0：建议先于扩展发布处理；P1：协议/安全/验收完整性；P2/P3：扩展和长期架构。每项描述的代码路径已读，环境表现未经真实PTY运行的部分明确保留为待验证。

## 总表

| ID | 优先级 | 发现 | 核验状态 |
|---|---|---|---|
| A01 | P0 | 非阻塞PTY短写未重试 | 源码确认；提取逻辑L01已复现 |
| A02 | P0 | SGR冒号预处理破坏分片不变性 | 源码确认；提取逻辑L02已复现 |
| A03 | P0 | 终端列坐标误用于Unicode字符串切片 | 源码确认；提取逻辑L03已复现 |
| A04 | P0 | 空闲会话不持续泵输出，读取缺预算 | 源码确认；实际产品运行待验证 |
| A05 | P0 | 连接线程数注释并未实现并发上限 | 源码确认；提取逻辑L04已复现；未进行外部攻击 |
| A06 | P0 | 单owner仍可能被阻塞回包与长wait卡住 | 源码确认；实际产品运行待验证 |
| A07 | P1 | 高亮等同选中、最宽等同当前项 | 源码确认；提取逻辑L05已复现 |
| A08 | P1 | 屏幕变化不是本次动作的因果确认 | 源码确认；实际产品运行待验证 |
| A09 | P1 | 多个只读等待不必串行排队 | 源码确认；实际产品运行待验证 |
| A10 | P1 | 进程退出结果与进程树生命周期不完整 | 源码确认；实际产品运行待验证 |
| A11 | P1 | 一次性脚本失败仍可能退出0 | 源码确认；实际产品运行待验证 |
| A12 | P1 | 感知降级未进入Agent默认响应 | 源码确认；实际产品运行待验证 |
| A13 | P1 | 构建系统最低版本声明不匹配 | 源码确认；实际产品运行待验证 |
| A14 | P1 | MCP风险标注和安全域需要纠正 | 源码确认；实际产品运行待验证 |
| A15 | P1 | 关键测试与文档基线不一致 | 源码确认；实际产品运行待验证 |
| A16 | P2 | 输入协议覆盖不够且未知键静默变文本 | 源码确认；实际产品运行待验证 |
| A17 | P2 | 观测预算、差分、回放未统一产品化 | 源码确认；实际产品运行待验证 |
| A18 | P2 | 兼容层边界和声明需收紧 | 源码确认；实际产品运行待验证 |
| A19 | P2 | 产品入口应聚焦而非重建已存在分发 | 源码确认；实际产品运行待验证 |
| A20 | P3 | 应用语义与人机共享是扩展机会 | 源码确认；实际产品运行待验证 |

## A01 · 非阻塞PTY短写未重试
**P0 · 源码确认；提取逻辑L01已复现**

定位：`smartcli_core/pty_backend.py :: PosixPtyBackend.write`。

**代码证据。** 仅调用一次os.write(fd,data)，未检查返回n；fd在spawn设为nonblocking。

**影响。** 长文本只输入前缀仍向调用端报告成功；EAGAIN也没有排队/重试契约。

**修复方向。** 按offset累积写入，EAGAIN等待可写；设置输入字节上限、截止时间、取消；区分排队/写完/应用确认。

**验收。** 注入1..N短写、EAGAIN、EINTR；最终字节精确相同，无重发前缀；截止前可取消。

来源：[SC03](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/pty_backend.py)；[STD01](https://docs.python.org/3/library/os.html#os.write)

## A02 · SGR冒号预处理破坏分片不变性
**P0 · 源码确认；提取逻辑L02已复现**

定位：`smartcli_core/screen_model.py :: _ByteStream.feed`。

**代码证据。** 正则只改写当前data内完整CSI…m；ESC[4:与3m分两次feed不被同样归一化。

**影响。** 相同终端字节因PTY分片不同而生成不同屏幕；冒号简单替换也改变subparameter语义。

**修复方向。** 引入有边界的流式控制序列状态，正确处理SGR子参数；不触碰OSC/DCS；保留原字节记录并标注不支持样式。

**验收。** 每个字节边界切分、随机chunk；文本/光标/支持属性一致；38:2::R:G:B、4:3m、OSC含冒号均有回归。

来源：[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)

## A03 · 终端列坐标误用于Unicode字符串切片
**P0 · 源码确认；提取逻辑L03已复现**

定位：`smartcli_core/snapshot.py :: build_snapshot`。

**代码证据。** menu_items使用display[y][a:b]；a,b是cell列，display已去掉wide continuation stub。

**影响。** 中文/日文/组合字符前缀使selected.text错误，模型可能操作错误对象。

**修复方向。** 从row_cells的data聚合span，定义wide continuation和grapheme边界；禁止用显示字符串下标替代cell坐标。

**验收。** 中文 OK中高亮cols5..7必须输出OK；combining/emoji/宽字被截断边界也测试。

来源：[SC06](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/snapshot.py)；[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)

## A04 · 空闲会话不持续泵输出，读取缺预算
**P0 · 源码确认；实际产品运行待验证**

定位：`skills/drive-tui/scripts/tui.py :: worker；pty_backend.py :: read_nonblocking`。

**代码证据。** worker在jobs.get超时后直接continue；只有观察/wait/alive时pump。POSIX drain直到不可读；Win队列无界。

**影响。** 后台应用可能因PTY回压停住；设备查询无人及时回复；高流量单次pump消耗无界。

**修复方向。** 单会话owner事件循环持续有界drain；每轮字节/时间预算；Win reader绑定会话队列并设高水位；明确丢弃/暂停/落盘策略。

**验收。** 无客户端轮询仍回答CPR并输出；有界高流量下snapshot/取消满足预算；内存达到高水位后不无限增长。

来源：[SC03](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/pty_backend.py)；[SC04](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/session.py)；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)

## A05 · 连接线程数注释并未实现并发上限
**P0 · 源码确认；提取逻辑L04已复现；未进行外部攻击**

定位：`skills/drive-tui/scripts/tui.py :: _serve_forever`。

**代码证据。** 每accept创建thread；len(readers)>64只剔除已结束线程；所有线程活跃时仍可继续增长。jobs也是无界。

**影响。** 本地未认证连接可持续消耗线程/内存；旧版本的9连接修复不等于全量资源耗尽防护。

**修复方向。** 认证前信号量或有界reader池；有界jobs；拒绝/速率限制与单用户配额；不让拒绝回复占worker。

**验收。** 用fake transport或本机隔离小上限测试：设置cap=4，活跃reader绝不>4；已认证控制仍可服务。

来源：[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)

## A06 · 单owner仍可能被阻塞回包与长wait卡住
**P0 · 源码确认；实际产品运行待验证**

定位：`skills/drive-tui/scripts/tui.py :: _reply / _drain_interleavable`。

**代码证据。** worker和poll hook直接sendall，POST_AUTH_TIMEOUT=60；close/resize排在长wait之后；排空queue没有每轮预算。

**影响。** 慢读客户端可延迟其他操作；大量fast请求可拖延timeout；取消没有独立控制路径。

**修复方向。** owner只产出immutable response；有界输出队列交给IO层；watcher非阻塞；close/cancel优先但不并发触碰模型。

**验收。** 慢读者不阻塞控制；并行3个watcher各自timeout/cancel；close可在长wait中触发，并等待真实退出后清理。

来源：[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)；[SC07](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/readiness.py)

## A07 · 高亮等同选中、最宽等同当前项
**P1 · 源码确认；提取逻辑L05已复现**

定位：`smartcli_core/snapshot.py :: build_snapshot`。

**代码证据。** bold或任何非default背景都加入menu_items；max(span.width)唯一选择。

**影响。** 主题背景/标题/状态栏胜过真实菜单项；errors也可能把红色说明或0 errors误判为错误。

**修复方向。** 分离observed_styles、inferences与app_semantics；输出候选、reason、provenance、置信等级；不足时selected=null。

**验收。** 背景整屏、粗体标题、底部状态栏、反色菜单、0 errors标注语料；报告误检/漏检而非只挑演示。

来源：[SC06](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/snapshot.py)；[SC16](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/perception_matrix.py)

## A08 · 屏幕变化不是本次动作的因果确认
**P1 · 源码确认；实际产品运行待验证**

定位：`session.py :: wait_change；readiness.py :: wait_for_regex / wait_ready`。

**代码证据。** 正则对整个当前屏幕搜索；min_wait只延迟；其他写者/后台动画也可改变hash。

**影响。** 旧prompt导致提前成功；画面改变被误作本动作完成；CRC是状态摘要不是交易ID。

**修复方向。** act_and_observe原子记录before_seq/action_id；expected_seq与geometry_epoch；单写者lease；结果分written/observed/applied/verified。

**验收。** 已有prompt、无回显输入、别的writer、动画和resize分别测试；不具备app ACK时不能填applied=true。

来源：[SC04](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/session.py)；[SC07](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/readiness.py)；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)；[CP19](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/crates/taria-mcp/src/bridge.rs)

## A09 · 多个只读等待不必串行排队
**P1 · 源码确认；实际产品运行待验证**

定位：`LIMITATIONS.md；readiness.py；tui.py`。

**代码证据。** 文档称一屏两个wait无独立意义，但不同predicate完全可在同一屏幕revision上独立评价。

**影响。** 并发监视/安全取消/人类查看的能力被无必要限制；clone会话会改变任务语义。

**修复方向。** 一个owner，多watcher状态机，各有predicate/deadline/cancel和after_seq；禁止多线程直接进入PtySession。

**验收。** 同一revision上regexA/regexB/exit各自返回；取消其中一个不取消进程或其他watcher。

来源：[SC13](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/references/LIMITATIONS.md)；[SC07](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/readiness.py)；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)

## A10 · 进程退出结果与进程树生命周期不完整
**P1 · 源码确认；实际产品运行待验证**

定位：`pty_backend.py :: is_alive / terminate；tui.py :: _run_daemon`。

**代码证据。** is_alive waitpid丢弃status；terminate已有reap但只针对pid；spawn/registry在try之前。

**影响。** 无法稳定提供exit_code；部分启动失败可能不走cleanup；后代是否存活需要验证。

**修复方向。** 缓存ExitState(exit_code,signal,reaped_at,identity)；spawn全过程资源事务；进程组/Windows Job Object可选约束。

**验收。** 重复is_alive不丢exit7；exec失败返回127原因；故障注入registry失败不漏PTY；后代清理分受控/逃逸策略。

来源：[SC03](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/pty_backend.py)；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)

## A11 · 一次性脚本失败仍可能退出0
**P1 · 源码确认；实际产品运行待验证**

定位：`skills/drive-tui/scripts/tui.py :: _run_steps`。

**代码证据。** wait超时或matched=False只emit，没有改变最终return0；只有未知action返回2。

**影响。** CI和Agent可能把未满足的检查当任务成功。

**修复方向。** 新assert步骤、--fail-on-timeout或v2默认strict；结果结构含step_id/status；保持旧脚本兼容标志。

**验收。** 故意不匹配返回非零；成功脚本返回0；未知操作与超时可区分；不把屏幕稳定当验收断言。

来源：[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)

## A12 · 感知降级未进入Agent默认响应
**P1 · 源码确认；实际产品运行待验证**

定位：`screen_model.py :: feed；tui.py :: _snapshot_response`。

**代码证据。** feed异常计数feed_errors存在，但整批余量丢弃且默认快照不暴露计数/失真。

**影响。** 模型看到正常ok却可能依据缺行/旧画面行动。

**修复方向。** fidelity.valid/degraded、feed_error_count、drop counters与mode support进入观测；原始日志可供离线恢复。

**验收。** 触发已有malformed parser案例，响应明确degraded；正常输入恢复有规则；不悄悄改成全部吞错。

来源：[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)；[SC09](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/mcp_server.py)

## A13 · 构建系统最低版本声明不匹配
**P1 · 源码确认；实际产品运行待验证**

定位：`pyproject.toml :: build-system.requires`。

**代码证据。** setuptools>=61，同时使用license字符串和project.license-files；官方支持从77.0.0开始。

**影响。** 固定旧构建依赖/离线或下限矩阵安装会失败；常规最新依赖构建成功掩盖问题。

**修复方向。** 下限提升到已验证的77.x适合版本；单独最低构建依赖测试，不回退现代license元数据。

**验收。** 在最低允许setuptools构建wheel+sdist+twinecheck；验证声明下限确实可用。

来源：[SC02](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/pyproject.toml)；[STD02](https://setuptools.pypa.io/en/latest/userguide/pyproject_config.html)

## A14 · MCP风险标注和安全域需要纠正
**P1 · 源码确认；实际产品运行待验证**

定位：`skills/drive-tui/scripts/mcp_server.py :: start / send_line / send_keys`。

**代码证据。** 输入工具destructiveHint=False/openWorldHint=False；任意程序可删除文件或访问网络；env经argv，token只防其他用户读取。

**影响。** 提示可能误导客户端审批；同UID受控子进程不是被隔离的不可信环境。

**修复方向。** 保守annotations；read/write/admin分capability；secret_ref不经argv；可选容器/Job/sandbox明确威胁模型，不承诺靠提示词隔离。

**验收。** annotations契约与实际权限一致；fake secret不出ps/log/artifacts；同UID信任边界写清；危险输入由策略/人类确认。

来源：[SC09](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/mcp_server.py)；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)；[STD03](https://modelcontextprotocol.io/specification/2026-07-28/schema)；[STD04](https://blog.modelcontextprotocol.io/posts/2026-03-16-tool-annotations/)

## A15 · 关键测试与文档基线不一致
**P1 · 源码确认；实际产品运行待验证**

定位：`ci.yml；tests/run_all.py；NEXT-STEPS.md`。

**代码证据。** run_all含daemon_concurrency但已读ci.yml不调用它也不调用run_all；NEXT称无rerun而run_all使用rerun=True。

**影响。** 关键修复可能不随PR持续验证；继任AI按旧文档错误判断已完成/未完成。

**修复方向。** 生成统一测试manifest并映射CI；记录first-pass、rerun、skip；机器生成版本/计数，历史附录与current state分离。

**验收。** 修改daemon_concurrency故意失败在目标CI中红；文档baseline自动同步；retry不得覆盖first-pass失败记录。

来源：[SC10](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/.github/workflows/ci.yml)；[SC11](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tests/run_all.py)；[SC12](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/NEXT-STEPS.md)

## A16 · 输入协议覆盖不够且未知键静默变文本
**P2 · 源码确认；实际产品运行待验证**

定位：`session.py :: _resolve_key / send_keys`。

**代码证据。** SS3适配已存在；未见mouse/bracketed paste/增强修饰键API；未知token回退literal。

**影响。** Ctrl+Up等错误拼写可能打进应用；粘贴/模式切换无法由工具面正确表达。

**修复方向。** 版本化KeySpec；unknown_key显式错误且literal单独type；模式感知paste/mouse；双层应用键与raw bytes分开。

**验收。** DECCKM原测试保留；BracketedPaste只在启用时包装；多行文本字节保真；鼠标协议按报告模式编码。

来源：[SC04](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/session.py)；[CP01](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/crates/tui-test/src/engine.rs)；[CP21](https://github.com/michaellee8/mcp-tui-driver/blob/main/README.md)

## A17 · 观测预算、差分、回放未统一产品化
**P2 · 源码确认；实际产品运行待验证**

定位：`screen_model.py；snapshot.py；tools/screenshot/*`。

**代码证据。** 已有compact snapshot、增量visual CRC和独立PNG工具；未见持久会话的统一artifact/seq/diff接口。

**影响。** 快照重复传输、旧日志丢失；人工难回看Agent实际做了什么。

**修复方向。** 复用PNG模块接readonly frame；event journal/checkpoint，region+since_seq/per-consumer；渲染元数据和安全redaction。

**验收。** 同一事件回放出一致cells；resize/input/output有序；失败证据可离线查看；正文/结构按需返回。

来源：[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)；[SC06](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/snapshot.py)；[SC14](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/shot.py)；[SC15](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/cli.py)；[CP06](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/src/host/eventLog.ts)；[CP25](https://github.com/nvms/tui-mcp/blob/main/README.md)；[CP26](https://github.com/ferodrigop/forge/blob/main/README.md)

## A18 · 兼容层边界和声明需收紧
**P2 · 源码确认；实际产品运行待验证**

定位：`screen_model.py :: _Screen；README`。

**代码证据。** 对pyte有大量行为修订；已明确IL/DL、DECSTBM在参考终端间有真实差异；部分标题却用never/always。

**影响。** 一套局部参考行为容易被误当普遍标准；更新依赖可能切换实现路径。

**修复方向。** TerminalEngine协议+terminal profile；先保持pyte默认，不急于换Rust；分级supported/degraded/unsupported。

**验收。** 双参考一致集必须过；分歧用profile标签；pyte capability两路径CI；端到端模式报告。

来源：[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)；[SC01](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/README.md)；[SC13](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/references/LIMITATIONS.md)；[CP01](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/crates/tui-test/src/engine.rs)

## A19 · 产品入口应聚焦而非重建已存在分发
**P2 · 源码确认；实际产品运行待验证**

定位：`README；pyproject；NEXT-STEPS`。

**代码证据。** MCP/agent关键词、PyPI、skills、registry与截图都已经存在；三个技能同等叙事会分散主用途。

**影响。** 新用户难立即判断这是Agent终端runtime还是装饰库；调研者只看热门榜会漏。

**修复方向。** 首页主叙事Agent终端运行时，三个入口清晰；艺术/UI保留为可选包与fixture优势；更正上一轮目录。

**验收。** 新用户从README完成Vim/菜单demo且能描述用途；pypi/import/bin命名表准确；不以star改变技术纳入。

来源：[SC01](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/README.md)；[SC02](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/pyproject.toml)；[SC12](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/NEXT-STEPS.md)

## A20 · 应用语义与人机共享是扩展机会
**P3 · 源码确认；实际产品运行待验证**

定位：`现有core/drive边界；tui-ui作为首个适配对象`。

**代码证据。** 现有推断不是应用widget tree；没有统一writer lease/attach接口的已核验证据。

**影响。** 复杂TUI要靠猜；人工接管与多Agent协作无法可靠确认控制权。

**修复方向。** 可选SemanticProvider；先tui-ui与Neovim/Textual，再taria桥；readonly attach+lease；通用屏幕回退继续存在。

**验收。** app ACK只用于真正应用确认；同屏只允许一个writer；human takeover撤销Agent写权限；语义未覆盖处回退。

来源：[SC06](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/snapshot.py)；[CP15](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/README.md)；[CP16](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/overlay-component.ts)；[CP18](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/README.md)；[CP19](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/crates/taria-mcp/src/bridge.rs)；[CP24](https://github.com/InfJoker/nvim-mcp/blob/main/README.md)

## 关于“已确认”与“实测”的边界

L01–L05仅是代码表达式/控制流的最小复现，不启动PTY、不调用pyte、不安装其他项目。它们证明特定算法反例，不能量化真实应用触发概率。`tests/test_audit_regressions.py`会导入真实SmartCLI，但本次只通过语法编译，尚未运行。资源耗尽和并发问题采用源码推断，不宣称攻击过任何在线服务。

一次缺陷修复必须先建立原代码失败、修复后通过的回归，再运行仓库既有门禁和native smoke。对于真实终端之间已有分歧的IL/DL等行为，应固定profile而非强行宣称唯一标准。
