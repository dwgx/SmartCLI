# 01 · 项目定位与竞争判断

## SmartCLI在这个问题空间的位置

这个研究不是评选最好看的终端，也不是列“自己具有TUI的coding agent”。目标是让Agent驱动**另一个持续运行的交互程序**，读取当前状态并核验操作。SmartCLI的drive-tui路径完整落在这个定义内。上一轮关键词检索没有以用户的项目为种子做覆盖检查，是遗漏的直接方法问题；不能从结果反推SmartCLI“不在受众范围”。现有topics已经有mcp、agent-tools、pty等，不应把补标签当解释。[SC01](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/README.md)；[SC17](https://api.github.com/repos/dwgx/SmartCLI/branches/main)

## 已经具备的优势——不要重复建设

**一，原生Windows路径是真实代码，不是只写一个Windows安装示例。** pywinpty/ConPTY与POSIX backend分离，CI配置覆盖三OS，另有三OS原生CLI/MCP smoke。对比依赖tmux或Unix socket的路线，Windows无需先装tmux/WSL是具体适配优势；但Microsoft tui-test等也走跨平台路线，所以不是全网独有壁垒，ConPTY Ctrl-C等限制仍需保留。[SC03](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/pty_backend.py)；[SC10](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/.github/workflows/ci.yml)；[SC13](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/references/LIMITATIONS.md)；[CP01](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/crates/tui-test/src/engine.rs)；[CP18](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/README.md)

**二，屏幕不是ANSI去色日志。** 长生命周期pyte stream、主/备屏、光标、反色、背景、双hash以及device-query回复均已有实现。相对仅PTY+正则去ANSI的包装器，这一层更贴近题目。这里的优势是表示方式和已覆盖场景，不能扩大成“所有Unicode、所有终端协议都正确”。[SC04](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/session.py)；[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)；[SC06](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/snapshot.py)

**三，Agent入口丰富且同core复用。** Python库、CLI、stdio MCP、可分发skills、wheel验证现成。不要规划一个“首个MCP版本”或再做第二套独立session engine。CLI/MCP内部应共享类型化应用服务，而不是一直经CLI的SystemExit/字符串JSON转译。[SC02](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/pyproject.toml)；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)；[SC09](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/mcp_server.py)；[SC10](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/.github/workflows/ci.yml)

**四，验证资产值得保留。** 现有差分、fuzz、虚拟时钟、宽字符、视觉变化、vendor/version/dependency同步、安装后MCP路径，是迭代基础；art/UI模块还能成为多主题、多宽度、动态状态的自有测试语料。它们不证明当前无缺陷，却让修复可被锁住。[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)；[SC10](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/.github/workflows/ci.yml)；[SC11](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tests/run_all.py)；[SC16](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/perception_matrix.py)

## 相对不足与参照对象

等待工具数量不少，但还不具备同等清晰的命令生命周期与取消语义；参考tui-test的idle/command/exit/ready边界与bnomei的旁路exit_code。日志与截图资产存在，但没有统一到每个持久会话的seq/record/replay/proof链；参考agent-tty。人类可直接接管同一screen的产品路径不明确；参考Pi的user-takeover状态，而不是简单开放第二个writer。推断选中项缺少拒判与置信来源；参考taria的应用ACK和真实widget tree，但必须承认它需要应用改造。[SC07](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/readiness.py)；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)；[SC14](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/shot.py)；[CP03](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/SKILL.md)；[CP12](https://github.com/bnomei/tmux-mcp/blob/c4762ea36b1a288a95ba5cc125154fae65a60ad5/src/tmux.rs)；[CP06](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/src/host/eventLog.ts)；[CP15](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/README.md)；[CP18](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/README.md)

## 应形成的差异化，而不是照抄功能菜单

建议以“终端观察可信度”为中心：每个动作都有写入回执；每次观测有明确revision、引擎/profile、降级告警；每个selected都是事实或有来源的推断；每个完成结论都有对应证据等级。对Windows和中文界面建立公开、可复制的失败语料和基线结果。这个定位需要用统一基准证明，目前只是值得投入的方向。

一个容易做错的宣传是“引入Rust/Ghostty就更快、更可靠”。语言和引擎名称不是证据。保持默认Python/pyte和既有接口，先用抽象层让参考引擎可替换，再实测启动成本、稳态延迟、帧保真、token与分发体积。另一个误区是为追分扩张音视频和GUI外壳，在输入仍可能丢尾巴时做这类功能不会改善真实成功率。

## 产品结构建议

主入口叫SmartCLI Agent Terminal Runtime（文案建议，不要求改PyPI项目名）；下面保留drive-tui、tui-ui、cmd-art。drive是控制与观测核心；tui-ui既是应用工具也是语义发布试点；cmd-art主要保留为创意工具和高频/样式压力fixture。pip核心依赖与图像/视频/语义适配分extras；现有独立skills继续可用。

建议不优先投入：重新命名发行包、全库Rust重写、自研完整VT规范、复制所有MCP工具、无租约的多Agent同时打字、把推断tree称为DOM、靠不断增加sleep修异步问题、只拼热门榜或star数量。
