# 04 · 可执行改进计划

总计38任务。建议角色Owner不是已指派人员，S/M/L仅表示相对复杂度。依赖关系是实施起点，不是假定已完成的状态。G7/G8部分任务应从第一轮并行运行，而不是等到最后才加测试。

## 关键依赖链

```text
T01 → T02 → T03 / T04 / T05 → T07 → T09 → T10
               T08 ─────────────┘
T07 → T11 → T12
T07 → T13 → T14 → T15 → T27
T10 + T11 + T14 → T16 → T17
T05 + T13 → T18 → T20 → T22
T14 + T19 → T24 → T25 → T26
T14 + T18 + T21 → T28 → T29
T01 → T31，T02/T07/T18 → T32，T20/T31/T32 → T33
```

## 建议PR拆分

PR1：基线与失败测试；PR2–4：短写、SGR、坐标分别修；PR5：配额；PR6：owner loop/IO分离；PR7：watcher/cancel；PR8：生命周期；PR9：类型化v2与seq；PR10：推断/降级与策略；PR11：rich input/command boundary；PR12：观察压缩；PR13：journal/截图；PR14：attach；PR15以后：语义与远程扩展。测试与文档随对应PR，不把所有修复堆成一条无法回滚的分支。

## G0 基线与回归
**阶段门：** 先得到可重现的失败与真实基线；不要引用历史44/44替代本次执行。

### T01 · 锁定代码、依赖、测试执行清单
P0 / S / 建议Owner：QA / 依赖：无
代码落点：`tests/；tools/；docs/`
实现：记录HEAD、tree、Python、pyte、ConPTY、TERM及pytest/脚本入口；生成test manifest，维护first-pass与rerun字段。
验收：源树与wheel分别跑；所有skip注明原因；不从历史文档推断绿灯。
关联：A15；[SC10](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/.github/workflows/ci.yml)；[SC11](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tests/run_all.py)；[SC12](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/NEXT-STEPS.md)

### T02 · 添加短写、分片、列坐标回归
P0 / S / 建议Owner：QA / 依赖：T01
代码落点：`tests/test_audit_regressions.py`
实现：先接入交付测试草案并确认原版本失败；逐个最小化，避免把实现细节变公共契约。
验收：三个错误路径在原版本红、修复后绿；故意还原bug仍红。
关联：A01,A02,A03；[SC03](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/pty_backend.py)；[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)；[SC06](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/snapshot.py)

## G1 核心正确性
**阶段门：** 输入不丢、分片不变、列坐标准确，原有fidelity/SS3/alt/hash契约全保留。

### T03 · 有界write_all与输入完成状态
P0 / M / 建议Owner：Core / 依赖：T02
代码落点：`smartcli_core/pty_backend.py；session.py`
实现：维护offset；EAGAIN可写通知；deadline/cancel；InputReceipt accepted/written分离。
验收：长文本byte-exact、EINTR不丢、没有无界busyloop。
关联：A01；[SC03](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/pty_backend.py)；[STD01](https://docs.python.org/3/library/os.html#os.write)

### T04 · 流式SGR与分片不变性
P0 / M / 建议Owner：Core / 依赖：T02
代码落点：`smartcli_core/screen_model.py`
实现：控制序列跨feed保留；正确subparams；长未终止序列有界；损坏序列恢复明确。
验收：所有切分点及随机切分得到等价supported cells。
关联：A02；[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)

### T05 · 统一cell span文字提取
P0 / M / 建议Owner：Core / 依赖：T02
代码落点：`snapshot.py；screen_model.py`
实现：cell_span_text作为唯一坐标转换；wide continuation与grapheme示例；复用到PNG/locators。
验收：中文 OK、日文、重音、ZWJ与右边界测试；不靠len(text)定义终端列。
关联：A03；[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)；[SC06](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/snapshot.py)；[SC14](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/shot.py)

### T06 · 修正构建依赖下限
P1 / S / 建议Owner：Release / 依赖：T01
代码落点：`pyproject.toml；CI package`
实现：setuptools下限提升到确认支持PEP639的版本；最低依赖构建测试。
验收：低于要求版本不被resolver选中；最低允许版本build/twine均通过。
关联：A13；[SC02](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/pyproject.toml)；[STD02](https://setuptools.pypa.io/en/latest/userguide/pyproject_config.html)

## G2 有界会话运行时
**阶段门：** 无人轮询仍推进；资源有界；独立取消；进程退出可证明。

### T07 · 单owner循环持续drain
P0 / L / 建议Owner：Runtime / 依赖：T03, T04, T05
代码落点：`smartcli_core/session.py；tui.py`
实现：OwnerLoop接收IO/events/requests；每tick字节与CPU预算；模型只在owner更新。
验收：无人轮询时子进程正常推进；CPR被及时回答；busy output可响应cancel。
关联：A04；[SC03](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/pty_backend.py)；[SC04](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/session.py)；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)；[CP09](https://github.com/onesuper/tui-use/blob/main/src/session.ts)

### T08 · 认证前与认证后资源配额
P0 / M / 建议Owner：Runtime / 依赖：T01
代码落点：`tui.py :: reader/accept/jobs`
实现：有界reader池/信号量、请求字节/连接率/queue长度；busy错误可重试且不泄漏screen。
验收：caps设小值做确定性测试，活跃线程和queue永不突破。
关联：A05；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)

### T09 · 把写回响应移出模型owner
P0 / M / 建议Owner：Runtime / 依赖：T07, T08
代码落点：`tui.py :: _reply`
实现：每连接有限输出缓冲/截止；IO线程或selector负责socket，owner不sendall。
验收：慢读者/断开连接不拖慢其他请求；有界response内存。
关联：A06；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)

### T10 · 多个watcher与优先cancel
P1 / L / 建议Owner：Runtime / 依赖：T07, T09
代码落点：`readiness.py；tui.py`
实现：将阻塞wait改为注册predicate；单owner对revision广播；每watcher独立deadline/cancel。
验收：3个watcher同时工作；一个取消不动其它；close不会等待60秒旧wait。
关联：A06,A09；[SC07](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/readiness.py)；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)；[SC13](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/references/LIMITATIONS.md)

### T11 · 缓存ExitState与启动资源事务
P1 / M / 建议Owner：Runtime / 依赖：T07
代码落点：`pty_backend.py；tui.py lifecycle`
实现：waitpid单处消费并缓存exit；spawn/registry失败finally覆盖；PID+startidentity；Windows队列绑定旧proc并join。
验收：exit7持久可查询；startup failure不留PTY；重用backend不串旧数据。
关联：A10；[SC03](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/pty_backend.py)；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)

### T12 · 进程树和会话限额治理
P1 / L / 建议Owner：Runtime / 依赖：T08, T11
代码落点：`pty_backend.py；tui.py`
实现：进程组/Job对象可选containment；idle TTL与保留期；容量预约原子化；GC先确认死亡。
验收：受控子孙被清理；逃逸策略明确；并发start不突破cap；不得盲删活token。
关联：A10；[SC03](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/pty_backend.py)；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)；[SC13](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/references/LIMITATIONS.md)

## G3 可信协议
**阶段门：** 结构化的因果、完成、权限和降级状态；v1迁移可控。

### T13 · 版本化请求响应与capabilities
P1 / M / 建议Owner：API / 依赖：T07
代码落点：`smartcli_core/protocol.py(新增)；drive adapters`
实现：定义v2 envelope、错误码、deadline、capabilities、engine/profile/version；消除内部JSON嵌套字符串。
验收：CLI/MCP/Python黄金响应一致；未知能力返回unsupported；v1仍可用。
关联：A11,A18；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)；[SC09](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/mcp_server.py)；[CP01](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/crates/tui-test/src/engine.rs)

### T14 · action_id/seq/epoch与原子act
P1 / L / 建议Owner：API / 依赖：T10, T13
代码落点：`session.py；新protocol/observations`
实现：按事件递增seq、screen_revision、geometry_epoch；先比expected_seq，再write，再注册after_seq predicate。
验收：旧screen/action、其他writer/resize不能伪证本动作；相同画面再现也有不同seq。
关联：A08；[SC04](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/session.py)；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)；[CP06](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/src/host/eventLog.ts)；[CP19](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/crates/taria-mcp/src/bridge.rs)

### T15 · writer lease与read-only能力
P1 / L / 建议Owner：Security / 依赖：T13, T14
代码落点：`tui.py；policy.py(新增)`
实现：观察与输入token分离；writer lease带expiry/fencing；同UID不是沙箱；human takeover可撤销。
验收：过期/旧fencing写入失败；readonly可watch不可type；并发不交错输入。
关联：A08,A14,A20；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)；[SC09](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/mcp_server.py)；[CP16](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/overlay-component.ts)

### T16 · 显式等待与命令边界
P1 / L / 建议Owner：API / 依赖：T10, T11, T14
代码落点：`session.py；readiness.py；shell adapters`
实现：新增wait_idle/wait_exit/wait_command；command支持shell hook或可信sidechannel，不通用屏幕猜测；任意TUI返回unsupported。
验收：shell command exit0/7正确；TUI idle不声称完成；marker若只匹配旧内容不产生新command verdict。
关联：A08,A10；[CP03](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/SKILL.md)；[CP12](https://github.com/bnomei/tmux-mcp/blob/c4762ea36b1a288a95ba5cc125154fae65a60ad5/src/tmux.rs)；[CP13](https://github.com/bnomei/tmux-mcp/blob/c4762ea36b1a288a95ba5cc125154fae65a60ad5/src/commands.rs)；[SC07](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/readiness.py)

### T17 · 脚本assert与失败退出码
P1 / M / 建议Owner：API / 依赖：T13, T16
代码落点：`tui.py :: _run_steps；CLI formatter`
实现：添加strict脚本模式、步骤ID、assert_text/assert_state、失败证据；保留旧模式显式迁移。
验收：超时失败返回非零且step原因完整；错误码稳定；测试框架可直接使用。
关联：A11；[SC08](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)；[CP03](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/SKILL.md)

### T18 · 不确定感知与降级状态
P1 / L / 建议Owner：Perception / 依赖：T05, T13
代码落点：`snapshot.py；protocol.py`
实现：保留raw事实，语义推断注明来源与candidate/confidence；feed_errors/dropped/bufferlag进入fidelity。
验收：theme误选能够abstain；退化状态不被ok覆盖；红色不自动当命令失败。
关联：A07,A12；[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)；[SC06](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/snapshot.py)；[SC16](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/perception_matrix.py)

### T19 · MCP风险提示、secret通道与沙箱策略
P1 / M / 建议Owner：Security / 依赖：T13, T15
代码落点：`mcp_server.py；policy.py`
实现：保守annotations；env通过受控IPC而非argv；默认不记录secret；提供可选sandbox adapter不伪装默认隔离。
验收：ps/log/report无fake secret；危险能力可拒绝；prompt injection正文始终作为不可信数据。
关联：A14；[SC09](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/mcp_server.py)；[STD03](https://modelcontextprotocol.io/specification/2026-07-28/schema)；[STD04](https://blog.modelcontextprotocol.io/posts/2026-03-16-tool-annotations/)

## G4 低成本观察与输入
**阶段门：** 以真实token/延迟数据验证region/diff与丰富输入，而非凭感觉宣称优化。

### T20 · 区域/差分/scrollback与reader游标
P2 / L / 建议Owner：Perception / 依赖：T14, T18
代码落点：`observations.py(新增)；screen_model.py`
实现：session内一个日志，reader各持since_seq；full/region/diff modes；超出保留期返回resync_required。
验收：两个reader读互不消费；resize显式resync；token预算截断字段可见。
关联：A17；[CP09](https://github.com/onesuper/tui-use/blob/main/src/session.ts)；[CP25](https://github.com/nvms/tui-mcp/blob/main/README.md)；[CP26](https://github.com/ferodrigop/forge/blob/main/README.md)

### T21 · 模式感知键、粘贴与鼠标
P2 / L / 建议Owner：Core / 依赖：T03, T13
代码落点：`session.py；input.py(新增)`
实现：KeySpec严格校验；DECCKM保持；paste/bracketed/mouse reporting模式；修饰键表与能力协商。
验收：每种模式在真实ncurses/Vim/菜单上验证；错误键不输入字面串。
关联：A16；[SC04](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/session.py)；[CP01](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/crates/tui-test/src/engine.rs)；[CP21](https://github.com/michaellee8/mcp-tui-driver/blob/main/README.md)

### T22 · 稳态判定区域化/事件化
P2 / M / 建议Owner：Perception / 依赖：T10, T20
代码落点：`readiness.py；observations.py`
实现：idle区分transport/content/visual；可忽略已声明动画region但不静默忽略selection。
验收：spinner不阻止等待另一region；选择移动必触发visual；deadline含所有工作耗时。
关联：A04,A08；[SC07](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/readiness.py)；[CP08](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/docs/USAGE.md)

### T23 · 可选终端引擎契约和profile
P2 / L / 建议Owner：Core / 依赖：T04, T05, T18
代码落点：`screen_model.py；engines/`
实现：抽象feed/frame/modes/replies/resize，pyte先实现；按证据选择xterm/Ghostty旁路实验，不默认迁移。
验收：现有fidelity回归全保留；IL/DL差异按profile，不把tmux投票当标准。
关联：A18；[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)；[CP01](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/crates/tui-test/src/engine.rs)；[CP09](https://github.com/onesuper/tui-use/blob/main/src/session.ts)

## G5 证据与协作
**阶段门：** 同一seq的日志/快照/截图；人类接管不串键；失败可离线复查。

### T24 · 追加事件日志与checkpoint
P2 / L / 建议Owner：Evidence / 依赖：T11, T14, T19
代码落点：`recording.py(新增)`
实现：schema/seq/monotonic ts记录输出/输入/resize/exit；write失败导致recording_degraded；设磁盘限额。
验收：重放同engine/version/profile得到同cells；存储满时不伪造完整记录；原始内容保留策略明确。
关联：A17；[CP06](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/src/host/eventLog.ts)；[CP07](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/README.md)

### T25 · 复用截图工具接入持久session
P2 / M / 建议Owner：Evidence / 依赖：T18, T24
代码落点：`tools/screenshot/shot.py；drive API`
实现：接immutable frame，而非再spawn；固定字体/宽度profile元数据；PNG作为可选extra；再考虑cast/video。
验收：capture对应确切seq；包内不分享字体文件；清楚标注reference renderer而非宿主真实截图。
关联：A17；[SC14](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/shot.py)；[SC15](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/cli.py)；[CP07](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/README.md)；[CP21](https://github.com/michaellee8/mcp-tui-driver/blob/main/README.md)

### T26 · 故障proof bundle与重放入口
P2 / M / 建议Owner：Evidence / 依赖：T17, T24, T25
代码落点：`artifacts/；CLI；MCP resources`
实现：输出manifest、事件片段、前后snapshot、PNG、动作及独立assert；可通过资源URI读取。
验收：离线另一个人能重演观察和检查断言；仅成功文本不能当证明。
关联：A17；[CP06](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/src/host/eventLog.ts)；[CP07](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/README.md)

### T27 · 人类只读attach与受控接管
P2 / L / 建议Owner：UX / 依赖：T15, T20, T24
代码落点：`attach viewer；policy`
实现：先readonly镜像，再接管lease；人接管导致agent fenced；同会话状态保留。
验收：接管/返还/掉线均不交错按键；kill监督与子进程真实退出分开。
关联：A20；[CP15](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/README.md)；[CP16](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/overlay-component.ts)；[CP22](https://github.com/elleryfamilia/terminal-mcp/blob/main/README.md)

## G6 可选语义适配
**阶段门：** 只在应用真实提供语义时返回app ACK；通用终端回退不丢。

### T28 · SemanticProvider与tui-ui试点
P3 / L / 建议Owner：Adapters / 依赖：T14, T18, T21
代码落点：`adapters/semantics.py；skills/tui-ui`
实现：定义app-provided vs inferred来源；widget ID、focus、actions、revision、ACK；先适配自己的UI做可验证纵切。
验收：同应用黑盒和语义模式任务等价；应用IGNORED与未确认可分；不谎称任意TUI有tree。
关联：A20；[CP18](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/README.md)；[CP19](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/crates/taria-mcp/src/bridge.rs)；[CP20](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/crates/taria-mcp/src/server.rs)

### T29 · Neovim/Textual/taria桥
P3 / L / 建议Owner：Adapters / 依赖：T28
代码落点：`adapters/nvim.py；adapters/textual.py；adapters/taria.py`
实现：各适配独立extras；RPC读取mode/buffer作应用增强；协议不支持直接回退cells；隔离许可/依赖。
验收：strict-UI赛道不得偷偷用RPC改文件；语义赛道明示使用；版本兼容与权限测试。
关联：A20；[CP18](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/README.md)；[CP24](https://github.com/InfJoker/nvim-mcp/blob/main/README.md)

### T30 · 远程会话传输作为独立后端
P3 / L / 建议Owner：Adapters / 依赖：T11, T15, T24
代码落点：`transports/ssh.py(可选)`
实现：本地SSH PTY保留screen engine；断线/重连标记，不承诺恢复已死进程；串口/3270以后需求再立项。
验收：断线不能成功回ACK；远程hostkey与凭证由受控配置，不自动跳过验证。
关联：A20；[SC03](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/pty_backend.py)

## G7 可比较评测
**阶段门：** 贯穿所有阶段；严格界面、应用适配、混合任务三赛道各有结果。

### T31 · 三赛道统一基准与独立裁判
P1 / L / 建议Owner：QA / 依赖：T01
代码落点：`benchmarks/；existing Harbor adapter`
实现：strict UI / adapted / mixed三赛道；固定模型/任务/预算，提取过程指标与最终独立assert；为每工具写同能力adapter。
验收：禁止sed绕过Vim算成功；未知结果fail或unknown不算pass；报告全部失败/skip。
关联：A15；[SC10](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/.github/workflows/ci.yml)；[CP05](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/crates/tui-test/tests/runtime.rs)

### T32 · 故障注入/差分/Unicode语料
P2 / L / 建议Owner：QA / 依赖：T02, T07, T18
代码落点：`tests/terminal_corpus；tools/screenshot/perception_matrix.py`
实现：片段随机化、宽度profile、CPU/load、断开慢读、device query、现代TUIs，固定seed保存最小repro。
验收：参考终端分歧标注；已知版本变动不偷偷删golden；本机fake攻击边界。
关联：A01,A02,A03,A04,A05；[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)；[SC16](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/perception_matrix.py)

### T33 · 效能与成本实测仪表
P2 / M / 建议Owner：QA / 依赖：T20, T31, T32
代码落点：`benchmarks/reporter.py`
实现：success/firstpass/median/p95/tokens/calls/RSS/recovery；机器性能固定；区分boot成本与持续session成本。
验收：给出样本量与不确定区间；无测量不写更快/省xx%；新增feature不提升空泛总分替代结果。
关联：A17；[CP01](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/crates/tui-test/src/engine.rs)；[CP06](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/src/host/eventLog.ts)

## G8 发布与生态
**阶段门：** 源/wheel/skills三发行面都有证据；用户明确授权后才发布。

### T34 · 测试manifest进CI，第一轮失败不可隐藏
P1 / M / 建议Owner：Release / 依赖：T01, T02, T06
代码落点：`ci.yml；tests/run_all.py`
实现：所有关键runtime/perception测试映射到OSmatrix；retry保留第一次结果；package源/轮子执行同契约。
验收：新A01–A06门禁在适用OS可执行；每个skip有reason；无需重启Dependabot版本PR。
关联：A15；[SC10](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/.github/workflows/ci.yml)；[SC11](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tests/run_all.py)；[SC17](https://api.github.com/repos/dwgx/SmartCLI/branches/main)

### T35 · README与可复現演示重构
P2 / M / 建议Owner：Docs / 依赖：T17, T25, T26
代码落点：`README*；docs/site；examples`
实现：首屏Agent terminal runtime；Vim/菜单/后台任务三demo；已有art/UI作为支持模块与测试资产；前后证据链接。
验收：按copy-paste路径检查Linux/Win/mac；不重复承诺已经存在的MCP/PyPI。
关联：A19；[SC01](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/README.md)；[SC02](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/pyproject.toml)；[SC12](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/NEXT-STEPS.md)

### T36 · 维护者/AI交接、元数据单一来源
P2 / M / 建议Owner：Docs / 依赖：T13, T34
代码落点：`HANDOFF.md；NEXT-STEPS.md；tools/sync_vendor.py`
实现：current baseline由代码生成；历史附录不可冒充当前；版本10点与vendor仍由门禁验证；逐PR可回滚。
验收：继任者可依据ID/sha/source/test复工，不靠聊天历史；不打包被排除资料。
关联：A15,A19；[SC11](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tests/run_all.py)；[SC12](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/NEXT-STEPS.md)；[SC13](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/references/LIMITATIONS.md)

### T37 · 分发依赖、许可和安全发布门
P2 / M / 建议Owner：Release / 依赖：T06, T24, T34, T36
代码落点：`pyproject；publish；NOTICE/SBOM`
实现：pin审查借鉴commit/许可；复用设计优先、拷贝代码前核license；最小extras；手动安全升级评估和发布证明。
验收：wheel/sdist/skills三产物内容清单；保留必要notice；无敏感配置/字体/排除目录；用户批准后再release。
关联：A13,A14,A19；[SC02](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/pyproject.toml)；[SC12](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/NEXT-STEPS.md)；[SC17](https://api.github.com/repos/dwgx/SmartCLI/branches/main)；[CP06](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/src/host/eventLog.ts)

### T38 · 补正调查目录与定向生态贡献
P2 / S / 建议Owner：Docs / 依赖：T01, T05, T23
代码落点：`corrected atlas；docs/comparison`
实现：SmartCLI纳入通用驱动；列出与各路线的边界；以真实repro向pyte贡献标准一致部分，不提交profile偏好为bug。
验收：原58条保留证据层级，新增第59条；不把本轮未重审工具标成已审计。
关联：A19；[SC01](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/README.md)；[SC05](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)；[SC12](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/NEXT-STEPS.md)

## 停止条件与不做清单

P0未关闭，不增加“不丢字/永远正确/可直接生产”的宣传。不以提高timeout、自动retry或忽略异常掩盖确定性缺陷。不通过牺牲CJK、Windows或现有默认行为来获得局部benchmark分数。不把v2设想写进README作为已发布能力。不把38项全部作为下一版本硬性范围：G1/G2/G3是首要可交付闭环，G4–G6按真实需求和评测投入。
