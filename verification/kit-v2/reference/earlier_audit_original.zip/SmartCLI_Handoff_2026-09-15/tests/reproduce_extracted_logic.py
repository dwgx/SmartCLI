#!/usr/bin/env python3
"""Reproduce five narrow code-path defects without installing SmartCLI.

This runs faithful reductions of the inspected expressions, NOT SmartCLI,
pyte, a PTY, a competitor, or the upstream regression suite. A reproduced=true
result documents the reduction only. No network, subprocess, or socket load.
Source baseline: dwgx/SmartCLI 701e61f6d69aa2420617edf80b1136df8d5e8cf7.
"""
from __future__ import annotations
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path


def main() -> int:
    results = []
    # A01: the inspected method issues one write and ignores the returned count.
    received = bytearray()
    calls = []
    def fake_os_write(fd: int, data: bytes) -> int:
        n = min(3, len(data))
        received.extend(data[:n])
        calls.append(n)
        return n
    payload = b"abcdefgh"
    fake_os_write(123, payload)  # inspected single-call behavior
    results.append(dict(id="L01",issue="A01",reproduced=bytes(received)!=payload,
                        sent=payload.decode(),received=received.decode(),write_calls=len(calls),
                        scope="extracted single-write logic with a short-writing stub"))
    # A02: exact per-chunk normalization expression from _ByteStream.feed.
    rx = re.compile(rb"\x1b\[([\d;:]*:[\d;:]*)m")
    def normalize(data: bytes) -> bytes:
        if b":" in data:
            data = rx.sub(lambda m: b"\x1b[" + m.group(1).replace(b":", b";") + b"m", data)
        return data
    raw = b"\x1b[4:3mU"
    whole = normalize(raw)
    split = normalize(raw[:4]) + normalize(raw[4:])
    results.append(dict(id="L02",issue="A02",reproduced=whole!=split,
                        whole_hex=whole.hex(),split_hex=split.hex(),
                        scope="preprocessor byte output only; pyte rendering not run"))
    # A03: highlighted ASCII columns after two double-width characters.
    display = "中文 OK"  # 中: cells 0..1, 文:2..3, space:4, O:5, K:6
    a,b=5,7
    observed = display[a:b].strip()
    results.append(dict(id="L03",issue="A03",reproduced=observed!="OK",
                        cell_span=[a,b],expected="OK",observed=observed,
                        scope="exact display[a:b].strip expression on a valid cell layout"))
    # A05: filtering dead threads is not a concurrency admission limit.
    class Live:
        def is_alive(self) -> bool: return True
    readers = [Live() for _ in range(64)]
    readers.append(Live())
    if len(readers)>64:
        readers=[x for x in readers if x.is_alive()]
    results.append(dict(id="L04",issue="A05",reproduced=len(readers)>64,
                        nominal_limit=64,active_readers_after_filter=len(readers),
                        scope="thread-list expression; no threads or connections created"))
    # A07: widest highlight does not encode a menu selection.
    @dataclass
    class Span:
        col_start:int
        col_end:int
        text:str
    spans=[Span(0,4,"Open"),Span(0,18,"BOLD STATUS HEADER")]
    selected=max(spans,key=lambda s:s.col_end-s.col_start)
    results.append(dict(id="L05",issue="A07",reproduced=selected.text!="Open",
                        intended_selected="Open",reported_selected=selected.text,
                        scope="exact widest-span selector on a counterexample"))
    output={"method":"extracted_logic_only","upstream_suite_executed":False,
            "pty_spawned":False,"competitor_benchmarks_executed":False,
            "all_counterexamples_reproduced":all(r['reproduced'] for r in results),"results":results}
    rendered=json.dumps(output,ensure_ascii=False,indent=2)
    print(rendered)
    if len(sys.argv)>1: Path(sys.argv[1]).write_text(rendered+"\n",encoding="utf-8")
    return 0 if output["all_counterexamples_reproduced"] else 1

if __name__=="__main__": raise SystemExit(main())
