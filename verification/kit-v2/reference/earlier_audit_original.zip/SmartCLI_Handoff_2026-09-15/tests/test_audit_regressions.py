#!/usr/bin/env python3
"""Regression tests to run in an actual SmartCLI checkout; NOT run in this audit.

From the repository root with its development dependencies installed:
    PYTHONPATH=. python /path/to/handoff/tests/test_audit_regressions.py

These assert the desired invariant and are expected to expose baseline defects.
They do not spawn a PTY, run untrusted programs, or open network connections.
The exact failure count on the target checkout is deliberately not claimed.
"""
from __future__ import annotations
import os
import unittest
from unittest.mock import patch

try:
    from smartcli_core.screen_model import ScreenModel
    from smartcli_core.snapshot import build_snapshot
except ImportError as exc:
    raise SystemExit("Run from the SmartCLI checkout with PYTHONPATH=. and pyte installed: " + str(exc))


class PerceptionRegressions(unittest.TestCase):
    def test_cell_coordinates_are_not_unicode_offsets(self):
        model=ScreenModel(cols=20,rows=3)
        model.feed("中文 ".encode("utf-8")+b"\x1b[7mOK\x1b[0m")
        snapshot=build_snapshot(model)
        matching=[s for s in snapshot.menu_items if s.row==0 and s.col_start==5 and s.col_end==7]
        self.assertEqual(len(matching),1,"expected the highlighted terminal cell span [5,7)")
        self.assertEqual(matching[0].text,"OK")

    def test_sgr_colon_feed_partition_invariant(self):
        raw=b"\x1b[4:3mU\x1b[0m"
        whole=ScreenModel(cols=20,rows=3)
        whole.feed(raw)
        expected=(whole.display,whole.cursor,whole.visual_hash())
        self.assertEqual(whole.display[0].strip(),"U")
        for cut in range(1,len(raw)):
            with self.subTest(cut=cut):
                split=ScreenModel(cols=20,rows=3)
                split.feed(raw[:cut]); split.feed(raw[cut:])
                self.assertEqual((split.display,split.cursor,split.visual_hash()),expected)


@unittest.skipIf(os.name=="nt","POSIX backend test; Windows has a separate write contract")
class WriteRegressions(unittest.TestCase):
    def test_partial_writes_do_not_lose_suffix(self):
        from smartcli_core.pty_backend import PosixPtyBackend
        backend=PosixPtyBackend()
        backend._fd=123456  # no real descriptor: os.write is patched
        received=bytearray()
        calls=0
        def partial_write(fd,data):
            nonlocal calls
            calls+=1
            if calls>100: raise AssertionError("write loop did not make bounded progress")
            self.assertEqual(fd,123456)
            n=min(2,len(data))
            received.extend(bytes(data[:n]))
            return n
        try:
            with patch("os.write",side_effect=partial_write):
                backend.write(b"abcdef")
            self.assertEqual(bytes(received),b"abcdef")
        finally:
            backend._fd=None
            backend._pid=None

if __name__=="__main__": unittest.main(verbosity=2)
