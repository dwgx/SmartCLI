# 契约草案

这些文件是升级设计，SmartCLI 0.2.3当前并不实现这些字段或API。example.invalid是刻意使用的不可部署schema标识，不代表真实服务。正式采用时由维护者分配稳定$id和版本。

schema限制applied必须来自application-ack，verified必须来自independent-verifier，但无法仅凭JSON验证来源是否真实；运行时仍需检查action_id、generation、lease、signature/peer权限和事件顺序。frame几何与text行数、inference坐标边界也需要额外应用层校验。

图像/日志秘密脱敏、能力token、writer lease不要直接嵌在可公开的observation里。seq是顺序信息，不是防伪凭证。
