# SmartCLI：源码审计、竞品对照与升级交接

**基线：`701e61f6d69aa2420617edf80b1136df8d5e8cf7` · 审查日：2026-09-15 · 在树版本：0.2.3**

上一轮漏掉 SmartCLI 是调研方法的遗漏，不是项目不属于主题。它拥有真实屏幕模拟、持续PTY、CLI/Python/MCP三类入口，本来就应进入“Agent使用终端”核心名单。本包同时补正原58条目录为59条，但不把之前未经本轮复核的条目伪装成新审计结果。

## 结论

SmartCLI不应先重写语言、换品牌或继续堆装饰效果。保留原生ConPTY/POSIX、pyte屏幕、双hash、紧凑snapshot、现有分发与测试资产；先修复可信交互链，然后构建版本化观察、可取消watcher、因果边界、人类接管与可复查证据。长期定位建议是：**Python友好、跨平台、可验证的Agent终端运行时**，而不只是“会发命令的MCP”。这是战略建议，不是已验证市场结论。

## 证据与完成范围

完成了固定SHA的核心模块源码审查、daemon/MCP主要路径审查、CI与发布契约检查，及关键竞品的源码/官方文档对照。源码与文档读取范围逐条写在`data/sources.json`，不声称读完所有仓库所有文件。GitHub latest release端点核对到v0.2.3（2026-08-09发布）。当前CI端到端状态没有验证成功：combined status无记录不能证明Actions绿色；特定workflow查询未被连接器接受。

**本地实际执行：5项提取逻辑的确定性反例，全数复现；两个交付Python测试文件做语法编译。未执行：SmartCLI完整安装、真实PTY/ConPTY测试、项目44项套件、竞品同环境基准。** 本地环境没有成功取得可运行的完整仓库与pyte，因此不把局部复现写成产品测试通过。真实导入的回归草案随包交付，需在项目环境验证。

本包没有修改、提交、推送或发布你的GitHub项目；全部是只读研究与本地交付。P0是我们建议的发布阻断优先级，不代表已获CVE/严重漏洞等级，不包含外部攻击试验。

## 内容入口

| 文件 | 用途 |
|---|---|
| `site/index.html` | 离线可搜索的评分、缺陷、任务与来源总览 |
| `SmartCLI_SCORECARD.xlsx` | 可改权重/分值的7产品、8维度评分；审计、任务、验收与来源 |
| `docs/01_EXECUTIVE_REVIEW.md` | 优劣势、竞争定位、应保留/应补齐 |
| `docs/02_CODE_AUDIT.md` | 20项发现，逐项定位、证据、修法、验收 |
| `docs/03_COMPETITOR_TRANSFER.md` | 借鉴哪份代码、迁移成哪项功能、哪些不能照搬 |
| `docs/04_ROADMAP.md` | 38个任务、依赖关系、阶段门、PR拆分 |
| `docs/05_ARCHITECTURE_ADRS.md` | OwnerLoop、seq/lease、引擎、语义、录制、安全的设计决策 |
| `docs/06_BENCHMARK_PLAN.md` | 20组验收场景、3条评测赛道、指标与对比公平性 |
| `docs/07_SCORE_METHODOLOGY.md` | 分值依据、权重、未知维度、非性能排名声明 |
| `docs/08_MIGRATION_RELEASE.md` | 兼容迁移、CI、供应链、许可和发布检查 |
| `AI_HANDOFF.md` | 可直接交给下一个工程师/Agent的任务起点 |
| `contracts/` | **建议中的v2**观察契约、示例；不是已发布API |
| `tests/` | 提取逻辑复现器；真实项目环境中的回归草案 |
| `evidence/local_logic_results.json` | 已运行的5项局部反例结果 |
| `data/` | 49条来源、20项审计、38项任务、评分、20组验收；CSV/JSON |
| `corrected_atlas/catalog.json` | 59条修正目录，保留旧证据层级 |

## 推荐执行起点

先阅读A01/A02/A03/A04/A05/A06；执行T01/T02，再分别实现T03/T04/T05。T08配额加固可与核心修复并行。无P0基线之前不做大规模引擎替换或“全面领先”宣传。按阶段门交付，不用一口气做38项的巨大PR。

S/M/L是相对变更规模，**不是工期承诺**；字段Owner是建议角色，不是已分派人员。所有后续任务状态初始都是待实施。

来源基线：[SC01](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/README.md)；[SC02](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/pyproject.toml)；[SC03](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/pty_backend.py)；[SC10](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/.github/workflows/ci.yml)；[SC17](https://api.github.com/repos/dwgx/SmartCLI/branches/main)；[SC18](https://github.com/dwgx/SmartCLI/releases/tag/v0.2.3)
