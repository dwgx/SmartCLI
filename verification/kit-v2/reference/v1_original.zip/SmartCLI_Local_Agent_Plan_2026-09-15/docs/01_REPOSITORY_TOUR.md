# 项目导览：先解释运行路径，再动源码

## 入口一：从外部工具走到会话

读 `pyproject.toml` 确认发行名、import名、console scripts和真实package-dir。沿 `skills/drive-tui/scripts/mcp_server.py` 的 start/snapshot/send/wait，追到 `tui.py` 的注册表、认证、_call、_handle、_serve_forever、_run_daemon。注意生命周期部分用subprocess，其他动作走token认证IPC；不要因为是同一MCP接口就假设线程和取消语义相同。[历史SC来源]

要求Agent回答：入口与底层是否重复序列化？哪一层判断alive？socket响应发送在哪个线程？一次长wait期间如何处理snapshot、resize、close？返回ok表示派发成功还是条件满足？这些问题比先列全部函数更重要。

## 入口二：从字节到当前画面

读 `smartcli_core/pty_backend.py` 的读/写/终止；`session.py` 的pump、send_keys、snapshot、wait；`screen_model.py` 的feed、_ByteStream、主备屏与visual_hash；`snapshot.py` 的build_snapshot；`readiness.py` 的谓词与deadline。

画出两条路径：目标输出 → PTY → parser → cell grid → snapshot；Agent输入 → mode-aware encoder → bytes → PTY → 应用事件。标注每个时刻可能仍有未处理字节，以及哪个操作会清dirty state。不要把独立observer直接连到会修改dirty的getter。[N02,N04]

## 入口三：已有的质量资产

读 `tests/run_all.py` 的真实列表与rerun；`.github/workflows/ci.yml` 的实际命令；`test_daemon_concurrency.py` 的fake session；相关fidelity、readiness、visual、security和vendor测试。区分纯内存、loopback、真实PTY、重型特效与发行测试。

读取 `tools/screenshot/`、已有drive_vim演示、Harbor/terminal-bench相关文件，决定复用点。当前AST索引只给符号/导入/行号，不解析动态导入和调用图；有CodeGraph就补充，没有则明确局限。

## 文档阅读的优先顺序

当前用户授权与仓库约束 → 当前源码与实际门禁 → 本轮本地证据 → 新研究的机制 → 旧审计 → README宣传文字。长HANDOFF和NEXT-STEPS按相关章节读取，不全量吞入模型上下文。

`PROJECT_MAP`应能让下一位Agent精确找到：主状态owner、阻塞I/O、输入进度、屏幕版本、session身份、token能力、子进程退出、缺口/错误传递和vendor同步。每个判断附file:symbol或具体证据，未知保持未知。

## 第一个小修改怎么选

A01短写适合替身后端；A02分片适合纯内存不变性；A03中文span适合cell fixture。先用probe工具判断当前代码的表现，再把有效负例迁入项目测试。若API已经变化导致PROBE_ERROR，先适配probe并记录，不能把工具自己的过时直接算产品bug。

本计划不要求先跑全套测试才可修任何代码。基线先限定相关轻量门禁，重型真实路径等批准后串行完成；最终明确缺哪些验证。全部任务细节见06_TASK_CARDS。
