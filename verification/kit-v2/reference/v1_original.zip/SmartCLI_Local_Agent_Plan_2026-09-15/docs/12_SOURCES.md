# 来源与代码挖掘索引

研究日期：2026-09-15。源码未运行不等于功能已验证；commit固定者可复核，未固定页面实施时重新pin。

## 本轮继续核查/机制补充

### N01 · dwgx/SmartCLI HEAD
证据：Live repository read。Runtime tested: false。
来源：[dwgx/SmartCLI HEAD](https://api.github.com/repos/dwgx/SmartCLI/branches/main)
固定ref：`701e61f6d69aa2420617edf80b1136df8d5e8cf7`
本轮HEAD仍与前次审计一致。

### N02 · SmartCLI repository operating constraints
证据：Source read。Runtime tested: false。
来源：[SmartCLI repository operating constraints](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/CLAUDE.md#L1-L145)
固定ref：`701e61f6d69aa2420617edf80b1136df8d5e8cf7`
一次一个PTY；重型测试另获同意；只有明确要求才commit；core需同步vendor。

### N03 · microsoft/tui-test command_settled / wait_command
证据：Source read, not run。Runtime tested: false。
来源：[microsoft/tui-test command_settled / wait_command](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/crates/tui-test/src/engine.rs#L1980-L2045)
固定ref：`d7e239c49a50d13e22be81fef207e7f4f85a509a`
无tracker.started时用300ms quiet；wait结束不等于命令任务成功；还须检查更高层error/cancel映射。

### N04 · SmartCLI daemon concurrency test
证据：Source read, not run。Runtime tested: false。
来源：[SmartCLI daemon concurrency test](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tests/test_daemon_concurrency.py#L1-L145)
固定ref：`701e61f6d69aa2420617edf80b1136df8d5e8cf7`
真实accept loop配fake session；线程身份应看ident不只name；不代表PTY实测。

### N05 · xterm.js flow control
证据：Official documentation。Runtime tested: false。
来源：[xterm.js flow control](https://xtermjs.org/docs/guides/flowcontrol/)
固定ref：无；需本地固定版本。
write是异步入队；callback表示该chunk解析完；高低水位要协作以免死锁；文档数字不直接当产品目标。

### N06 · xterm.js Terminal API
证据：Official documentation。Runtime tested: false。
来源：[xterm.js Terminal API](https://xtermjs.org/docs/api/terminal/classes/terminal/)
固定ref：无；需本地固定版本。
onWriteParsed可能在仍有pending writes时触发；有模式、Unicode和binary input边界。

### N07 · Microsoft ConPTY lifecycle
证据：Official documentation。Runtime tested: false。
来源：[Microsoft ConPTY lifecycle](https://learn.microsoft.com/en-us/windows/console/creating-a-pseudoconsole-session)
固定ref：无；需本地固定版本。
ClosePseudoConsole可能产生final frame；同步单线程通信可死锁；与模型单owner不冲突。

### N08 · MCP cancellation specification
证据：Versioned specification。Runtime tested: false。
来源：[MCP cancellation specification](https://modelcontextprotocol.io/specification/2025-11-25/basic/utilities/cancellation)
固定ref：`2025-11-25`
notifications/cancelled与tasks/cancel不同；取消请求不是默认杀死整个终端。

### N09 · MCP tasks specification
证据：Versioned specification。Runtime tested: false。
来源：[MCP tasks specification](https://modelcontextprotocol.io/specification/2025-11-25/basic/utilities/tasks)
固定ref：`2025-11-25`
该版本将Tasks标为experimental；需要capability协商，不能要求所有客户端已支持。

### N10 · kitty keyboard protocol
证据：Official protocol。Runtime tested: false。
来源：[kitty keyboard protocol](https://sw.kovidgoyal.net/kitty/keyboard-protocol/)
固定ref：无；需本地固定版本。
progressive enhancement协商；按键事件与文字并非同一物；老协议存在歧义。

### N11 · VS Code shell integration
证据：Official documentation。Runtime tested: false。
来源：[VS Code shell integration](https://code.visualstudio.com/docs/terminal/shell-integration)
固定ref：无；需本地固定版本。
OSC633与133完成标记、nonce及quality；ConPTY标记位置有平台边界。

### N12 · Unicode UAX29
证据：Official standard。Runtime tested: false。
来源：[Unicode UAX29](https://www.unicode.org/reports/tr29/)
固定ref：无；需本地固定版本。
grapheme segmentation不等于终端cell width；实施时固定Unicode版本/profile。

### N13 · Hypothesis stateful testing
证据：Official documentation。Runtime tested: false。
来源：[Hypothesis stateful testing](https://hypothesis.readthedocs.io/en/latest/stateful.html)
固定ref：无；需本地固定版本。
状态机生成动作序列、bundle与不变量；不用真实PTY做密集模型测试。

### N14 · taria bridge source
证据：Source read, not run。Runtime tested: false。
来源：[taria bridge source](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/crates/taria-mcp/src/bridge.rs#L1-L180)
固定ref：`0178e037f302cc253170f912f488157890c028e7`
watch持有状态，broadcast发布ACK，有界input/line；原tree与typed tree分工；断线不继续操作旧树。

### N15 · agent-tty event log (previous read carried forward)
证据：Prior source evidence, not re-run。Runtime tested: false。
来源：[agent-tty event log (previous read carried forward)](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/src/host/eventLog.ts)
固定ref：`ebff2c23d8273be09812d841305a4f6246ccf47e`
写入队列失败传播与序号；本计划继续参考，但未对全项目做新的运行审计。

### N16 · SmartCLI readiness implementation (same baseline)
证据：Prior source evidence, new inference。Runtime tested: false。
来源：[SmartCLI readiness implementation (same baseline)](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/readiness.py)
固定ref：`701e61f6d69aa2420617edf80b1136df8d5e8cf7`
外层deadline无法抢占同步rx.search；这是待本地小规模验证的机制性风险，非已确认资源攻击结果。

### N17 · tui-use PTY event path (previous read)
证据：Prior source evidence, new inference。Runtime tested: false。
来源：[tui-use PTY event path (previous read)](https://github.com/onesuper/tui-use/blob/main/src/session.ts)
固定ref：无；需本地固定版本。
terminal.write(data)后通知不必然表示解析完成；须核对完整wait路径后判断有无实际竞态。 此历史文件读取未固定commit，本地需重新pin。

## 沿用前轮索引

这些是历史来源记录，不代表本轮逐项重读或运行。
### SC01
[dwgx/SmartCLI README.md](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/README.md)
项目定位与产品入口 · prior evidence=D · runtime_tested=False

### SC02
[dwgx/SmartCLI pyproject.toml](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/pyproject.toml)
完整读取；在树版本0.2.3；构建下限61与PEP639不符 · prior evidence=S · runtime_tested=False

### SC03
[dwgx/SmartCLI smartcli_core/pty_backend.py](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/pty_backend.py)
完整读取；短写、read预算、进程状态 · prior evidence=S · runtime_tested=False

### SC04
[dwgx/SmartCLI smartcli_core/session.py](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/session.py)
主要方法读取；尾部_hash_change实现未完整获取 · prior evidence=S · runtime_tested=False

### SC05
[dwgx/SmartCLI smartcli_core/screen_model.py](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/screen_model.py)
分段完整读取；SGR分片、pyte兼容层、CRC · prior evidence=S · runtime_tested=False

### SC06
[dwgx/SmartCLI smartcli_core/snapshot.py](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/snapshot.py)
完整读取；列号切片与语义启发式 · prior evidence=S · runtime_tested=False

### SC07
[dwgx/SmartCLI smartcli_core/readiness.py](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/smartcli_core/readiness.py)
完整读取；marker/stability/on_poll · prior evidence=S · runtime_tested=False

### SC08
[dwgx/SmartCLI skills/drive-tui/scripts/tui.py](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/tui.py)
读取1–820行，覆盖认证、serve、worker、start、run_steps；未声称完整读取53KB文件 · prior evidence=S · runtime_tested=False

### SC09
[dwgx/SmartCLI skills/drive-tui/scripts/mcp_server.py](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/scripts/mcp_server.py)
读取1–280行，覆盖生命周期、snapshot、输入与annotations · prior evidence=S · runtime_tested=False

### SC10
[dwgx/SmartCLI .github/workflows/ci.yml](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/.github/workflows/ci.yml)
完整读取：三OS矩阵、native smoke、wheel；非当前CI结果 · prior evidence=S · runtime_tested=False

### SC11
[dwgx/SmartCLI tests/run_all.py](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tests/run_all.py)
读取1–250行；包含daemon_concurrency与rerun=True · prior evidence=S · runtime_tested=False

### SC12
[dwgx/SmartCLI NEXT-STEPS.md](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/NEXT-STEPS.md)
读取前180行；旧基线与完成项混排 · prior evidence=D · runtime_tested=False

### SC13
[dwgx/SmartCLI skills/drive-tui/references/LIMITATIONS.md](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/skills/drive-tui/references/LIMITATIONS.md)
完整读取；已修复项、ConPTY限制、长wait主张 · prior evidence=D · runtime_tested=False

### SC14
[dwgx/SmartCLI tools/screenshot/shot.py](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/shot.py)
代码搜索摘要核对：已有pyte→PIL截图工具；未完整审查 · prior evidence=X · runtime_tested=False

### SC15
[dwgx/SmartCLI tools/screenshot/cli.py](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/cli.py)
已有截图matrix/fx/selftest；需接到持久会话，而非从零造截图 · prior evidence=X · runtime_tested=False

### SC16
[dwgx/SmartCLI tools/screenshot/perception_matrix.py](https://github.com/dwgx/SmartCLI/blob/701e61f6d69aa2420617edf80b1136df8d5e8cf7/tools/screenshot/perception_matrix.py)
已有感知矩阵；可以扩展选择误检语料 · prior evidence=X · runtime_tested=False

### SC17
[dwgx/SmartCLI ](https://api.github.com/repos/dwgx/SmartCLI/branches/main)
主分支SHA及2026-09-03提交；关闭Dependabot版本PR · prior evidence=M · runtime_tested=False

### SC18
[dwgx/SmartCLI ](https://github.com/dwgx/SmartCLI/releases/tag/v0.2.3)
latest API验证：2026-08-09发布0.2.3；不是本地安装验证 · prior evidence=M · runtime_tested=False

### CP01
[microsoft/tui-test crates/tui-test/src/engine.rs](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/crates/tui-test/src/engine.rs)
读取1–180：LiveFrame、模式、interrupt、recording、操作串行；没有声称它支持任意并行wait · prior evidence=S · runtime_tested=False

### CP02
[microsoft/tui-test bindings/js/src/client.ts](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/bindings/js/src/client.ts)
waitCommand与按类别timeout委托 · prior evidence=X · runtime_tested=False

### CP03
[microsoft/tui-test SKILL.md](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/SKILL.md)
idle / command / exit / ready边界 · prior evidence=D · runtime_tested=False

### CP04
[microsoft/tui-test README.md](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/README.md)
当前beta及多语言/多后端工具面；未运行 · prior evidence=D · runtime_tested=False

### CP05
[microsoft/tui-test crates/tui-test/tests/runtime.rs](https://github.com/microsoft/tui-test/blob/d7e239c49a50d13e22be81fef207e7f4f85a509a/crates/tui-test/tests/runtime.rs)
运行时wait command测试存在，不代表本次已跑 · prior evidence=X · runtime_tested=False

### CP06
[coder/agent-tty src/host/eventLog.ts](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/src/host/eventLog.ts)
读取1–250；事件类型、seq、schema、失败传播 · prior evidence=S · runtime_tested=False

### CP07
[coder/agent-tty README.md](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/README.md)
PTY+Ghostty、截图/录制、平台与run边界 · prior evidence=D · runtime_tested=False

### CP08
[coder/agent-tty docs/USAGE.md](https://github.com/coder/agent-tty/blob/ebff2c23d8273be09812d841305a4f6246ccf47e/docs/USAGE.md)
cursor-line scope与stable等待 · prior evidence=D · runtime_tested=False

### CP09
[onesuper/tui-use src/session.ts](https://github.com/onesuper/tui-use/blob/main/src/session.ts)
读取1–240；xterm渲染、scrollback10000、事件监听、固定key表 · prior evidence=S · runtime_tested=False

### CP10
[onesuper/tui-use src/highlights.ts](https://github.com/onesuper/tui-use/blob/main/src/highlights.ts)
上一轮源码完整读取；inverse run，仍需CJK专项核对 · prior evidence=S · runtime_tested=False

### CP11
[onesuper/tui-use README.md](https://github.com/onesuper/tui-use/blob/main/README.md)
CLI start/snapshot/press/wait · prior evidence=D · runtime_tested=False

### CP12
[bnomei/tmux-mcp src/tmux.rs](https://github.com/bnomei/tmux-mcp/blob/c4762ea36b1a288a95ba5cc125154fae65a60ad5/src/tmux.rs)
read_exit_code_buffer，私有paste buffer旁路 · prior evidence=X · runtime_tested=False

### CP13
[bnomei/tmux-mcp src/commands.rs](https://github.com/bnomei/tmux-mcp/blob/c4762ea36b1a288a95ba5cc125154fae65a60ad5/src/commands.rs)
wait_result→exit_code读取与清理 · prior evidence=X · runtime_tested=False

### CP14
[bnomei/tmux-mcp src/types.rs](https://github.com/bnomei/tmux-mcp/blob/c4762ea36b1a288a95ba5cc125154fae65a60ad5/src/types.rs)
执行状态、command、exit_code类型 · prior evidence=X · runtime_tested=False

### CP15
[nicobailon/pi-interactive-shell README.md](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/README.md)
读取1–200；4模式、人工接管、quiet completion不是命令结果 · prior evidence=D · runtime_tested=False

### CP16
[nicobailon/pi-interactive-shell overlay-component.ts](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/overlay-component.ts)
user-takeover 与 exited分离 · prior evidence=X · runtime_tested=False

### CP17
[nicobailon/pi-interactive-shell index.ts](https://github.com/nicobailon/pi-interactive-shell/blob/981ca320530610e5f2c03a05b0a73b4e3b4490af/index.ts)
通知、预算、tail和userTookOver · prior evidence=X · runtime_tested=False

### CP18
[y0sif/taria README.md](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/README.md)
prealpha0.2，协议1；应用发布tree、输入ACK；Unix、单bridge限制 · prior evidence=D · runtime_tested=False

### CP19
[y0sif/taria crates/taria-mcp/src/bridge.rs](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/crates/taria-mcp/src/bridge.rs)
单调input_id · prior evidence=X · runtime_tested=False

### CP20
[y0sif/taria crates/taria-mcp/src/server.rs](https://github.com/y0sif/taria/blob/0178e037f302cc253170f912f488157890c028e7/crates/taria-mcp/src/server.rs)
输入队列受QUEUE_WAIT约束 · prior evidence=X · runtime_tested=False

### CP21
[michaellee8/mcp-tui-driver README.md](https://github.com/michaellee8/mcp-tui-driver/blob/main/README.md)
读取1–165；PNG、mouse、modifiers、JS、asciicast · prior evidence=D · runtime_tested=False

### CP22
[elleryfamilia/terminal-mcp README.md](https://github.com/elleryfamilia/terminal-mcp/blob/main/README.md)
上一轮官方README：共享host、text/ANSI/PNG，本轮未重审源码 · prior evidence=P · runtime_tested=False

### CP23
[aybelatchane/mcp-server-terminal README.md](https://github.com/aybelatchane/mcp-server-terminal/blob/main/README.md)
上一轮官方README：TST，推断结构不等于原生DOM · prior evidence=P · runtime_tested=False

### CP24
[InfJoker/nvim-mcp README.md](https://github.com/InfJoker/nvim-mcp/blob/main/README.md)
上一轮官方README：Neovim RPC/PTY/截图适配 · prior evidence=P · runtime_tested=False

### CP25
[nvms/tui-mcp README.md](https://github.com/nvms/tui-mcp/blob/main/README.md)
上一轮官方README：region/scrollback · prior evidence=P · runtime_tested=False

### CP26
[ferodrigop/forge README.md](https://github.com/ferodrigop/forge/blob/main/README.md)
上一轮官方README：独立reader cursor与read_screen · prior evidence=P · runtime_tested=False

### CP27
[pproenca/agent-tui README.md](https://github.com/pproenca/agent-tui/blob/main/README.md)
上一轮官方README：Rust daemon CLI/RPC，Unix限制 · prior evidence=P · runtime_tested=False

### STD01
[ ](https://docs.python.org/3/library/os.html#os.write)
os.write返回实际写入字节数 · prior evidence=D · runtime_tested=False

### STD02
[ ](https://setuptools.pypa.io/en/latest/userguide/pyproject_config.html)
PEP639功能自setuptools77.0.0支持 · prior evidence=D · runtime_tested=False

### STD03
[ ](https://modelcontextprotocol.io/specification/2026-07-28/schema)
ToolAnnotations提示，不是权限执行边界 · prior evidence=D · runtime_tested=False

### STD04
[ ](https://blog.modelcontextprotocol.io/posts/2026-03-16-tool-annotations/)
风险提示语义与默认保守值 · prior evidence=D · runtime_tested=False
