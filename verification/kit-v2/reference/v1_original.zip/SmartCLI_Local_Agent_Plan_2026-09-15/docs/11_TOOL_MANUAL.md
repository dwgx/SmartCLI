# 本地工具手册

所有路径示例均是占位。全局参数`--repo`、`--run`放在子命令前。Python3.10+；工具本身仅标准库。

| 命令 | 当前实际实现 | 是否执行目标代码 |
|---|---|---|
| verify-kit | 检查发布manifest的文件SHA256和任务DAG | 否 |
| doctor | Git元数据、有限源码SHA/AST索引、指令与工具可用性 | 不导入/不测试 |
| init | RUN状态、初始inventory、PROJECT_MAP模板 | 否 |
| acknowledge | 确认地图非空且无TODO，记录HEAD | 否；不认证理解质量 |
| next | 依赖满足的候选任务 | 否；不是自动编码调度器 |
| probe | 本地core的4个断言与2个诊断 | 是，显式参数；不spawnPTY |
| gate --id ID | 白名单Memory脚本，一次一个、有timeout/log上限 | 是，显式参数 |
| record | 记录状态与证据；verified/refuted检查closure结构 | 否；不证明结论真实性 |
| propose | 登记X-实验任务并检查依赖环 | 否 |
| status / handoff | 查看state或生成可续接RESUME | 否 |

## 默认安全行为

RUN在repo和kit之外；不覆盖已初始化state；拒绝路径穿越和symlink证据；同一个RUN有exclusive lock；保留首次日志，不自动重跑。达到timeout或输出预算时记录非PASS。PASS_WITH_SKIP不等于全通过。缺pyte的probe返回NOT_RUN，不会自动pip安装。

不要把源码执行白名单当sandbox。任何被修改的脚本都须重新审查。静态inventory是有大小/文件数上限的索引，报告被省略项；AST不给完整动态调用图。被扫描范围之外的改变不在该fingerprint内。

## 推荐轻量门禁

先读config/gates.json和当前脚本，再按当前任务选单项。readiness、wait-any、visual-change、terminal-fidelity、vendor/version/dependency-sync是候选。probe重构接口后可能PROBE_ERROR，先区分工具过时与产品缺陷。

```bash
python tools/agentctl.py --repo REPO --run RUN gate --id readiness --python VENV_PYTHON --execute-reviewed-code
python tools/agentctl.py --repo REPO --run RUN gate --id vendor-sync --python VENV_PYTHON --execute-reviewed-code
```

`daemon-concurrency`虽然用fake session，仍有真实loopback/thread；本runner保守拒绝，由Agent审查并通过自己的本地工具串行运行。cli-pty、mcp-pty、all、fx-live同样拒绝，遵循单会话与重活审批。

## 状态与证据

先在RUN/evidence写一条研究/实现记录，可标investigating或implemented。verified/refuted需使用templates/CLOSURE.json，填当前source_fingerprint、验收、证据和真实review方法，依赖也要关闭。工具仅结构检查。不要为了满足状态检查捏造pass。

```bash
python tools/agentctl.py --repo REPO --run RUN record --task T03 --status implemented --evidence evidence/T03-implementation.md
python tools/agentctl.py --repo REPO --run RUN record --task T03 --status verified --evidence evidence/T03-closure.json
python tools/agentctl.py --repo REPO --run RUN handoff
```

HEAD前进后重新阅读约束并acknowledge；源文件变化后旧closure需要影响复审。handoff列出指纹与当前不同的closure提醒，不自动把过去证据删除或变绿。依赖图仅建议，修改图需保留ADR和旧记录。

## 新实验

复制templates/EXPERIMENT.json到RUN，填写可证伪假设和停止规则，证据放RUN/evidence。`propose --spec experiment.json`只添加任务，不自动执行、不授权新风险。新任务ID使用X-前缀，不能覆盖T01–T50。

## 自测

```bash
python -B -m unittest discover -s tests -v
```

这些只验证工作台的临时fixture、子进程预算和协调记录，不启动SmartCLI PTY。Windows/macOS仍需本地验证；本包evidence只记录实际执行平台。
