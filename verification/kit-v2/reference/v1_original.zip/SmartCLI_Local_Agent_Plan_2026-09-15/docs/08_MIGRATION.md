# 迁移、发行与可逆性

## 渐进迁移

保留PtySession、现有CLI verbs和MCP入口的兼容facade。新runtime内部返回类型化Outcome，旧入口可以通过明确的legacy映射保持行为；旧字段何时弃用由版本策略决定，不直接删除。

需要专项迁移的行为：未知按键从字面fallback改为错误；wait_ready从marker OR stable到更严格分类；json字符串改为对象；close从即时ok到closing/exited；CRC hash改为revision主身份；default selection从最大高亮到候选/unknown。每一项要有旧客户端fixture和新客户端负例。

命令返回的进程exitcode、tool调用是否成功、业务assertion是否通过分开，不改变一个exitcode含义而不更新文档。严格脚本模式等待未满足应失败；容错探索模式可继续，但要显式声明策略。

## 发行面

源码checkout、wheel、独立skills/vendor、stdio MCP、容器（存在且获准使用时）单列验收。不要只在repo根导入成功就认为wheel完整。core每次变更同步_vendor，并保留版本、依赖、文档计数门。

不在此次工作中自动bump版本、tag、commit、push、发布PyPI或MCP目录。准备候选release说明和证据，用户决定发布。遵循现有不自动生成AI署名和不擅自重新开启Dependabot版本更新的约束。[N02]

## 依赖与来源

引入代码前固定commit、读LICENSE和文件头、记录改写来源与兼容评估。参考协议不等于可随意复制任意实现。源文件版权声明和NOTICE按实际许可处理；不把本计划当作许可结论。新原生依赖先可选安装，失败应可诊断而不是启动崩溃。

## 回滚

补丁按问题拆分；每项记录受影响API、fixture、vendor、文档和数据格式。操作journal版本变化要给reader兼容策略；不能让回滚版误读新版记录后输出假证据。不覆盖用户历史session registry，旧session可以只读并要求显式迁移。
