#!/usr/bin/env python3
"""Local, model-independent SmartCLI research workbench (stdlib only).

Does not edit the target repository, install packages, contact a model, commit,
push, or launch PTY gates. Running reviewed Python code is explicitly opt-in.
Timeouts and output limits are guardrails, NOT an operating-system sandbox.
"""
from __future__ import annotations

import argparse
import ast
import contextlib
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import threading
import time
from typing import Any

KIT = Path(__file__).resolve().parents[1]
BASELINE = "701e61f6d69aa2420617edf80b1136df8d5e8cf7"
MAX_FILE = 2 * 1024 * 1024
MAX_SCAN = 32 * 1024 * 1024
MAX_FILES = 5000
MAX_LOG = 2 * 1024 * 1024
STATUSES = {"pending", "investigating", "implemented", "verified", "refuted", "blocked", "deferred"}
SATISFIED = {"verified", "refuted"}
SCOPES = {"smartcli_core", "skills", "tests", "tools", "examples", ".github", ".claude-plugin"}
SUFFIXES = {".py", ".toml", ".json", ".yaml", ".yml", ".md", ".txt", ".sh", ".ps1"}
SKIP_DIRS = {".git", ".venv", "venv", "node_modules", "__pycache__", "out", "dist", "build", ".pytest_cache", "research", "_refs"}


def utc() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_json(path: Path) -> Any:
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 8 * MAX_FILE:
        raise ValueError(f"not a bounded regular JSON file: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise ValueError("refusing symlink output")
    tmp = path.with_name(path.name + ".tmp")
    # Caller holds the run lock for state mutations; never follow an existing tmp.
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(value, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink()


def contained(root: Path, relative: str, must_exist: bool = True) -> Path:
    p = Path(relative)
    if p.is_absolute() or ".." in p.parts or not relative or "\\" in relative:
        raise ValueError("use a relative, forward-slash path without '..'")
    target = root / p
    cur = root
    for part in p.parts:
        cur = cur / part
        if cur.is_symlink():
            raise ValueError("symlink paths are not accepted")
    resolved = target.resolve()
    if not resolved.is_relative_to(root.resolve()):
        raise ValueError("path escapes root")
    if must_exist and not resolved.is_file():
        raise ValueError(f"file not found: {relative}")
    return resolved


def repo_root(raw: str | None) -> Path:
    if not raw:
        raise ValueError("--repo is required")
    root = Path(raw).expanduser().resolve()
    if not (root / "smartcli_core").is_dir() or not (root / "pyproject.toml").is_file():
        raise ValueError("target must contain smartcli_core/ and pyproject.toml")
    return root


def run_root(raw: str | None, repo: Path) -> Path:
    if not raw:
        raise ValueError("--run is required; choose a separate output directory")
    root = Path(raw).expanduser().resolve()
    if root == repo or root.is_relative_to(repo):
        raise ValueError("--run must be outside the target repository")
    if root == KIT or root.is_relative_to(KIT):
        raise ValueError("--run must be outside the plan kit (preserve its manifest)")
    return root


def git_read(repo: Path, *args: str) -> dict:
    env = dict(os.environ, GIT_OPTIONAL_LOCKS="0", GIT_TERMINAL_PROMPT="0")
    try:
        p = subprocess.run(["git", "-c", "core.fsmonitor=false", "-C", str(repo), *args], stdin=subprocess.DEVNULL,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=5, env=env)
        text = p.stdout[:200_000].decode("utf-8", "replace").strip()
        return {"ok": p.returncode == 0, "text": text, "returncode": p.returncode}
    except (OSError, subprocess.TimeoutExpired):
        return {"ok": False, "text": "", "returncode": None}


def inventory(repo: Path) -> dict:
    files: dict[str, dict] = {}
    warnings: list[str] = []
    total = 0
    for base, dirs, names in os.walk(repo, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not (Path(base) / d).is_symlink())
        relbase = Path(base).relative_to(repo)
        if relbase.parts and relbase.parts[0] not in SCOPES:
            dirs[:] = []
            continue
        for name in sorted(names):
            p = Path(base) / name
            if p.is_symlink() or p.suffix not in SUFFIXES or name.startswith(".env"):
                continue
            rel = p.relative_to(repo).as_posix()
            try:
                size = p.stat().st_size
                if size > MAX_FILE:
                    warnings.append(f"oversize omitted: {rel}")
                    continue
                if total + size > MAX_SCAN or len(files) >= MAX_FILES:
                    warnings.append("inventory budget exhausted; no completeness claim")
                    dirs[:] = []
                    return finish_inventory(files, warnings, total)
                raw = p.read_bytes()
            except OSError:
                warnings.append(f"unreadable: {rel}")
                continue
            total += len(raw)
            entry: dict[str, Any] = {"sha256": digest(raw), "bytes": len(raw)}
            if p.suffix == ".py":
                try:
                    tree = ast.parse(raw, filename=rel)
                    entry["symbols"] = [
                        {"name": n.name, "kind": type(n).__name__, "line": n.lineno,
                         "end": getattr(n, "end_lineno", n.lineno)}
                        for n in ast.walk(tree)
                        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
                    ]
                    entry["imports"] = sorted({n.module or "" for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)} |
                                              {a.name for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names})
                except (SyntaxError, ValueError, UnicodeError, RecursionError) as e:
                    entry["ast_error"] = type(e).__name__
            files[rel] = entry
    return finish_inventory(files, warnings, total)


def finish_inventory(files: dict, warnings: list, total: int) -> dict:
    payload = [[p, v["sha256"]] for p, v in sorted(files.items())]
    return {"files": files, "fingerprint": digest(json.dumps(payload).encode()),
            "warnings": warnings, "bytes_read": total,
            "scope": "bounded source/config inventory; not full-disk or security attestation"}


def doctor(repo: Path) -> dict:
    inv = inventory(repo)
    head = git_read(repo, "rev-parse", "HEAD")
    status = git_read(repo, "status", "--porcelain", "--untracked-files=normal")
    instructions = sorted(p for p in inv["files"] if Path(p).name in {"AGENTS.md", "CLAUDE.md", "SKILL.md"})
    return {"schema_version": 1, "created_at": utc(), "repo": str(repo),
            "head": head["text"] if head["ok"] else None,
            "audit_baseline": BASELINE, "baseline_matches": head["text"] == BASELINE,
            "git_status_known": status["ok"], "dirty": bool(status["text"]) if status["ok"] else None,
            "git_status": status["text"], "runner_python": sys.version,
            "runner_executable": sys.executable, "platform": sys.platform,
            "term": os.environ.get("TERM"),
            "available_tools": {k: shutil.which(k) for k in ("git", "codegraph", "rg", "fd", "ruff", "mypy")},
            "instructions": instructions, "inventory": inv,
            "trust_note": "No repository imports or tests were executed. AST is an index, not a resolved call graph."}


@contextlib.contextmanager
def lock(run: Path):
    run.mkdir(parents=True, exist_ok=True)
    p = run / ".agentctl.lock"
    try:
        fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError as e:
        raise ValueError("run is locked; inspect its owner before any manual stale-lock removal") from e
    try:
        os.write(fd, json.dumps({"pid": os.getpid(), "created_at": utc()}).encode())
        os.close(fd)
        yield
    finally:
        p.unlink(missing_ok=True)


def read_state(run: Path, repo: Path) -> dict:
    state = load_json(run / "state.json")
    if Path(state["repo"]).resolve() != repo:
        raise ValueError("run belongs to another repository")
    return state


def all_tasks(run: Path | None = None) -> list[dict]:
    result = load_json(KIT / "data" / "tasks.json")
    if run and (run / "proposals.json").exists():
        result += load_json(run / "proposals.json")
    validate_dag(result)
    return result


def validate_dag(tasks: list[dict]) -> None:
    ids = {t["id"] for t in tasks}
    if len(ids) != len(tasks):
        raise ValueError("duplicate task id")
    graph = {t["id"]: t.get("dependencies", []) for t in tasks}
    seen: set[str] = set()
    active: set[str] = set()
    def visit(k: str) -> None:
        if k not in graph:
            raise ValueError(f"unknown dependency {k}")
        if k in active:
            raise ValueError("cyclic task dependencies")
        if k in seen:
            return
        active.add(k)
        for dep in graph[k]:
            visit(dep)
        active.remove(k)
        seen.add(k)
    for k in graph:
        visit(k)


def ready_tasks(tasks: list[dict], state: dict) -> list[dict]:
    statuses = state["tasks"]
    ready = [t for t in tasks if statuses.get(t["id"], {}).get("status", "pending") in {"pending", "investigating"}
             and all(statuses.get(d, {}).get("status") in SATISFIED for d in t.get("dependencies", []))]
    return sorted(ready, key=lambda t: (t["priority"], t["id"]))


def require_ack(state: dict, repo: Path) -> None:
    if not state.get("understanding"):
        raise ValueError("write PROJECT_MAP.md and use acknowledge before executing repository code")
    current = git_read(repo, "rev-parse", "HEAD")
    now = current["text"] if current["ok"] else None
    if now != state["understanding"].get("head"):
        raise ValueError("HEAD changed: reread repository guidance and acknowledge an updated project map")


def bounded_run(argv: list[str], cwd: Path, logfile: Path, timeout: float = 30,
                max_log: int = MAX_LOG, env: dict | None = None) -> dict:
    """One subprocess, no shell, bounded retained output; process groups on POSIX.

    This is not a sandbox. Arbitrary reviewed code can still spawn escaped
    descendants or access resources. PTY/heavy gates are therefore excluded.
    """
    if timeout <= 0 or timeout > 180:
        raise ValueError("timeout must be in (0, 180] seconds")
    logfile.parent.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    params: dict = {"cwd": str(cwd), "stdin": subprocess.DEVNULL, "stdout": subprocess.PIPE,
                    "stderr": subprocess.STDOUT, "env": env}
    if os.name != "nt":
        params["start_new_session"] = True
    else:
        params["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
    # Open exclusively before spawning so a colliding log cannot deadlock stdout.
    log_handle = logfile.open("xb")
    try:
        p = subprocess.Popen(argv, **params)
    except OSError as exc:
        raw = (f"START_FAILED: {type(exc).__name__}: {exc}\n").encode("utf-8", "replace")
        with log_handle:
            log_handle.write(raw[:max_log])
        return {"status": "START_FAILED", "returncode": None,
                "elapsed_s": round(time.monotonic() - start, 4), "argv": argv,
                "log_sha256": digest(raw[:max_log]), "timeout_s": timeout,
                "output_bytes_seen": len(raw), "output_bytes_retained": min(len(raw), max_log),
                "created_at": utc(), "evidence_complete": True}
    log_errors: list[str] = []
    counters = {"total": 0, "written": 0}
    overflow = threading.Event()
    def drain() -> None:
        assert p.stdout is not None
        try:
            with log_handle as log:
                while True:
                    chunk = p.stdout.read(4096)
                    if not chunk:
                        break
                    counters["total"] += len(chunk)
                    keep = max(0, min(len(chunk), max_log - counters["written"]))
                    if keep:
                        log.write(chunk[:keep])
                        counters["written"] += keep
                    if counters["total"] > max_log:
                        overflow.set()
        except OSError as exc:
            log_errors.append(f"{type(exc).__name__}: {exc}")
    reader = threading.Thread(target=drain, daemon=True)
    reader.start()
    stop_reason = None
    while p.poll() is None:
        if log_errors:
            stop_reason = "LOG_IO_ERROR"
        elif overflow.is_set():
            stop_reason = "OUTPUT_LIMIT"
        elif time.monotonic() - start > timeout:
            stop_reason = "TIMEOUT"
        if stop_reason:
            try:
                if os.name != "nt":
                    os.killpg(p.pid, signal.SIGKILL)
                else:
                    p.kill()
            except ProcessLookupError:
                pass
            break
        time.sleep(0.02)
    try:
        rc = p.wait(timeout=3)
    except subprocess.TimeoutExpired:
        rc = None
        stop_reason = "CLEANUP_UNCONFIRMED"
    reader.join(timeout=2)
    if reader.is_alive():
        stop_reason = "DESCENDANT_PIPE_UNCONFIRMED"
    if log_errors:
        stop_reason = "LOG_IO_ERROR"
    if overflow.is_set() and stop_reason is None:
        stop_reason = "OUTPUT_LIMIT"
    raw = logfile.read_bytes() if logfile.exists() else b""
    txt = raw.decode("utf-8", "replace")
    internal_skip = bool(re.search(r"(?im)^\s*(?:\[\s*)?SKIP(?:PED)?(?:\s*\])?\b", txt))
    status = stop_reason or ("PASS_WITH_SKIP" if rc == 0 and internal_skip else "PASS" if rc == 0 else "FAIL")
    return {"status": status, "returncode": rc, "elapsed_s": round(time.monotonic() - start, 4),
            "output_bytes_seen": counters["total"], "output_bytes_retained": len(raw),
            "log_sha256": digest(raw), "argv": argv, "timeout_s": timeout,
            "descendant_cleanup": "not an OS containment guarantee", "created_at": utc(),
            "evidence_complete": not reader.is_alive() and not log_errors, "log_errors": log_errors}


def child_environment(repo: Path, run: Path) -> dict:
    allowed = {"PATH", "HOME", "USERPROFILE", "SYSTEMROOT", "WINDIR", "COMSPEC", "PATHEXT", "TEMP", "TMP", "TMPDIR", "LOCALAPPDATA", "APPDATA", "LANG", "LC_ALL", "TERM"}
    env = {k: v for k, v in os.environ.items() if k.upper() in allowed}
    env.update({"PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1", "PYTHONDONTWRITEBYTECODE": "1",
                "PYTHONPATH": str(repo), "SMARTCLI_TUI_DIR": str(run / "owned_sessions")})
    return env


def execute(args: argparse.Namespace, repo: Path, run: Path, state: dict, probe: bool) -> int:
    require_ack(state, repo)
    if not args.execute_reviewed_code:
        raise ValueError("code execution is opt-in: inspect the entrypoint and imports, then pass --execute-reviewed-code")
    gates = load_json(KIT / "config" / "gates.json")
    if probe:
        g = {"id": "actual-core-probes", "path": "tools/probe_core.py", "tier": "memory", "timeout": 25}
        script = KIT / g["path"]
    else:
        g = next((g for g in gates if g["id"] == args.id), None)
        if not g:
            raise ValueError("unknown gate id; inspect config/gates.json")
        if g["tier"] != "memory":
            raise ValueError("this runner refuses PTY/heavy/network gates; use the manual approval + single-session procedure")
        script = contained(repo, g["path"])
    py = Path(args.python).expanduser().resolve() if args.python else Path(sys.executable)
    if not py.is_file():
        raise ValueError("--python must be the path to an existing interpreter")
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S%f")
    prefix = f"{stamp}-{g['id']}"
    logfile = run / "evidence" / f"{prefix}.log"
    before = inventory(repo)
    argv = [str(py), "-B", str(script)]
    if probe:
        argv += ["--repo", str(repo)]
    result = bounded_run(argv, repo, logfile, g["timeout"], env=child_environment(repo, run))
    after = inventory(repo)
    result.update({"gate": g["id"], "log": logfile.relative_to(run).as_posix(),
                   "source_fingerprint_before": before["fingerprint"], "source_fingerprint_after": after["fingerprint"],
                   "inventory_warnings": before["warnings"] + after["warnings"],
                   "head": git_read(repo, "rev-parse", "HEAD")["text"],
                   "entrypoint_sha256": digest(script.read_bytes()), "automatic_retry": False})
    if before["fingerprint"] != after["fingerprint"]:
        result["status"] = "SOURCE_CHANGED_DURING_GATE"
    if probe:
        try:
            result["probe_result"] = json.loads(logfile.read_text(encoding="utf-8"))
        except (ValueError, UnicodeError):
            result["probe_result"] = None
    result_path = run / "evidence" / f"{prefix}.json"
    write_json(result_path, result)
    state.setdefault("runs", []).append(result_path.relative_to(run).as_posix())
    write_json(run / "state.json", state)
    print(json.dumps({"status": result["status"], "evidence": str(result_path)}, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS" else 1


def closure_check(doc: dict, run: Path, status: str, current_fingerprint: str) -> None:
    fields = {"task_id", "status", "summary", "source_fingerprint", "acceptance_checks", "evidence", "review"}
    if not fields <= doc.keys() or doc["status"] != status or len(doc["summary"].strip()) < 20:
        raise ValueError("closure requires task_id, status, substantive summary, source_fingerprint, acceptance_checks, evidence, review")
    if doc["source_fingerprint"] != current_fingerprint:
        raise ValueError("closure fingerprint does not match current bounded source inventory")
    if not isinstance(doc["acceptance_checks"], list) or not doc["acceptance_checks"]:
        raise ValueError("at least one acceptance check is required")
    for check in doc["acceptance_checks"]:
        if not isinstance(check, dict) or not check.get("name") or not check.get("scope"):
            raise ValueError("acceptance checks must name the check, result and actual scope")
        allowed = {"pass", "not_applicable"} if status == "verified" else {"pass", "refuted", "not_applicable"}
        if check.get("result") not in allowed:
            raise ValueError("an unresolved/failed acceptance check cannot close the task")
    if status == "verified" and doc.get("blockers"):
        raise ValueError("a verified closure cannot contain unresolved blockers")
    if not isinstance(doc["evidence"], list) or not doc["evidence"]:
        raise ValueError("closure needs evidence files, not just a status assertion")
    for rel in doc["evidence"]:
        contained(run, rel)
    if not isinstance(doc["review"], dict) or not doc["review"].get("method"):
        raise ValueError("declare review method; same-model self-review must not be called independent")


def handoff(run: Path, repo: Path, state: dict) -> str:
    current = inventory(repo)
    ready = ready_tasks(all_tasks(run), state)[:8]
    stale = [k for k,v in state["tasks"].items() if v.get("status") in SATISFIED and v.get("source_fingerprint") != current["fingerprint"]]
    lines = ["# SmartCLI local handoff", "", f"Generated: {utc()}", f"Repository: `{repo}`",
             f"Current HEAD: `{git_read(repo, 'rev-parse', 'HEAD')['text']}`",
             f"Inventory fingerprint: `{current['fingerprint']}`", "",
             "## Status (agent-reported, evidence-linked; not automatic correctness certification)"]
    for k,v in state["tasks"].items():
        if v["status"] != "pending":
            lines.append(f"- {k}: {v['status']} — {v.get('evidence', '')}")
    lines += ["", "## Ready candidates (dependency routing only; revalidate if source changed)"]
    lines += [f"- {t['id']} {t['title']}" for t in ready]
    lines += ["", "## Earlier closures requiring impact review", ", ".join(stale) or "None recorded.",
              "", "## Next agent", "Read current AGENTS/CLAUDE guidance and PROJECT_MAP before code.",
              "Review evidence/*.json and their immutable first-attempt logs. Do not equate a missing run with success.",
              "Never auto-run full/PTy tests, commit, push, release or upload logs."]
    return "\n".join(lines) + "\n"


def verify_kit() -> dict:
    m = load_json(KIT / "MANIFEST.json")
    failures = []
    for rel, expected in m["files"].items():
        try:
            p = contained(KIT, rel)
            if digest(p.read_bytes()) != expected:
                failures.append(rel)
        except ValueError:
            failures.append(rel)
    validate_dag(load_json(KIT / "data" / "tasks.json"))
    return {"ok": not failures, "checked_files": len(m["files"]), "mismatches": failures,
            "note": "Integrity check only; manifest is not a signature or proof of safety."}


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--repo"); p.add_argument("--run")
    sub = p.add_subparsers(dest="cmd", required=True)
    for name in ("doctor", "init", "next", "status", "handoff", "verify-kit"):
        sub.add_parser(name)
    ack = sub.add_parser("acknowledge"); ack.add_argument("--project-map", default="PROJECT_MAP.md")
    for name in ("gate", "probe"):
        q = sub.add_parser(name)
        q.add_argument("--execute-reviewed-code", action="store_true")
        q.add_argument("--python")
        if name == "gate": q.add_argument("--id", required=True)
    rec = sub.add_parser("record")
    rec.add_argument("--task", required=True); rec.add_argument("--status", choices=sorted(STATUSES), required=True)
    rec.add_argument("--evidence", required=True)
    prop = sub.add_parser("propose"); prop.add_argument("--spec", required=True)
    args = p.parse_args(argv)
    try:
        if args.cmd == "verify-kit":
            r = verify_kit(); print(json.dumps(r, ensure_ascii=False, indent=2)); return 0 if r["ok"] else 1
        repo = repo_root(args.repo)
        if args.cmd == "doctor":
            print(json.dumps(doctor(repo), ensure_ascii=False, indent=2)); return 0
        run = run_root(args.run, repo)
        with lock(run):
            if args.cmd == "init":
                if (run / "state.json").exists(): raise ValueError("run already initialized; use status/handoff, not reset")
                d = doctor(repo)
                write_json(run / "inventory.initial.json", d)
                tasks = all_tasks()
                state = {"schema_version": 1, "created_at": utc(), "repo": str(repo), "initial_head": d["head"],
                         "initial_fingerprint": d["inventory"]["fingerprint"], "understanding": None, "runs": [],
                         "tasks": {t["id"]: {"status": "pending"} for t in tasks}}
                write_json(run / "state.json", state)
                (run / "evidence").mkdir(exist_ok=True)
                if not (run / "PROJECT_MAP.md").exists():
                    shutil.copyfile(KIT / "templates" / "PROJECT_MAP.md", run / "PROJECT_MAP.md")
                (run / "READ_NEXT.md").write_text("# Read next\n\nRead the target's AGENTS.md / CLAUDE.md, then the kit's START_HERE.md and docs/01_REPOSITORY_TOUR.md.\nFill PROJECT_MAP.md using actual files and symbols. The inventory is static; no target code has run.\n", encoding="utf-8")
                print(json.dumps({"ok": True, "run": str(run), "head": d["head"], "next": "Read guidance, fill PROJECT_MAP.md, acknowledge; do not execute all gates."}, ensure_ascii=False, indent=2))
                return 0
            state = read_state(run, repo)
            if args.cmd == "acknowledge":
                path = contained(run, args.project_map)
                text = path.read_text(encoding="utf-8")
                if len(text) < 500 or "[TODO]" in text:
                    raise ValueError("replace all [TODO] markers with a substantive, source-linked project map")
                state["understanding"] = {"file": args.project_map, "sha256": digest(path.read_bytes()),
                                          "head": git_read(repo, "rev-parse", "HEAD")["text"] or None, "at": utc(),
                                          "note": "agent acknowledgment, not proof of understanding"}
                write_json(run / "state.json", state)
                print(json.dumps({"ok": True, "note": "acknowledged; repository code still requires explicit execution flag"})); return 0
            if args.cmd in {"gate", "probe"}:
                return execute(args, repo, run, state, args.cmd == "probe")
            if args.cmd == "record":
                if args.task not in state["tasks"]: raise ValueError("unknown task")
                ev = contained(run, args.evidence)
                fp = inventory(repo)["fingerprint"]
                if args.status in SATISFIED:
                    require_ack(state, repo)
                    doc = load_json(ev)
                    if doc.get("task_id") != args.task: raise ValueError("closure task id mismatch")
                    closure_check(doc, run, args.status, fp)
                    task = next(t for t in all_tasks(run) if t["id"] == args.task)
                    if any(state["tasks"].get(d,{}).get("status") not in SATISFIED for d in task.get("dependencies",[])):
                        raise ValueError("unclosed dependencies; revise task graph explicitly, do not silently bypass it")
                previous = state["tasks"][args.task]
                state["tasks"][args.task] = {"status": args.status, "evidence": args.evidence,
                                            "evidence_sha256": digest(ev.read_bytes()), "at": utc(), "source_fingerprint": fp}
                history = state.setdefault("history", [])
                history.append({"task": args.task, "previous": previous, "new": state["tasks"][args.task]})
                write_json(run / "state.json", state)
                print(json.dumps({"ok": True, "note": "status is agent-reported; closure structure was checked, not semantic correctness"})); return 0
            if args.cmd == "propose":
                proposal = load_json(contained(run, args.spec))
                if not re.fullmatch(r"X-[A-Za-z0-9_-]{1,40}", proposal.get("id", "")):
                    raise ValueError("new task ids must start X-")
                if not {"title","priority","dependencies","hypothesis","acceptance","stop_rule","evidence"} <= proposal.keys():
                    raise ValueError("proposal missing required fields; see templates/EXPERIMENT.json")
                if proposal["priority"] not in {"P0","P1","P2","P3"}: raise ValueError("invalid priority")
                for rel in proposal["evidence"]: contained(run, rel)
                combined = all_tasks(run) + [proposal]; validate_dag(combined)
                proposals = load_json(run / "proposals.json") if (run / "proposals.json").exists() else []
                proposals.append(proposal); write_json(run / "proposals.json", proposals)
                state["tasks"][proposal["id"]] = {"status": "pending"}; write_json(run / "state.json", state)
                print(json.dumps({"ok": True, "id": proposal["id"]})); return 0
            if args.cmd == "next":
                print(json.dumps({"ready_candidates": ready_tasks(all_tasks(run),state)[:8],
                                  "note": "dependency suggestions only; local agent may re-plan with evidence"}, ensure_ascii=False,indent=2)); return 0
            if args.cmd == "status":
                print(json.dumps(state,ensure_ascii=False,indent=2)); return 0
            if args.cmd == "handoff":
                path = run / "RESUME.md"
                if path.is_symlink(): raise ValueError("symlink output refused")
                path.write_text(handoff(run,repo,state),encoding="utf-8")
                print(json.dumps({"ok":True,"handoff":str(path)})); return 0
    except (ValueError, OSError, KeyError, TypeError, json.JSONDecodeError) as e:
        print(json.dumps({"ok":False,"error":str(e)},ensure_ascii=False),file=sys.stderr)
        return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
