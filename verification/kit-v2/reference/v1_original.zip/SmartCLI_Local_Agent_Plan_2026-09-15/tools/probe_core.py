#!/usr/bin/env python3
"""Small probes of the actual local SmartCLI core. No PTY spawn or network.

Explicit code-execution consent belongs to the calling agent. Importing a
repository is code execution, not a sandbox. Missing dependencies yield NOT_RUN.
Some diagnostics demonstrate a contract, rather than declaring it a bug.
"""
from __future__ import annotations
import argparse
import importlib.metadata
import json
from pathlib import Path
import sys
from unittest.mock import patch

sys.dont_write_bytecode = True


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', required=True)
    args = p.parse_args()
    root = Path(args.repo).expanduser().resolve()
    sys.path.insert(0, str(root))
    report = {'schema_version': 1, 'repo': str(root), 'python': sys.version,
              'scope': 'actual imported core; in-memory/mocked I/O only; no real terminal fidelity verdict',
              'cases': []}
    try:
        import smartcli_core
        from smartcli_core.screen_model import ScreenModel
        from smartcli_core.snapshot import build_snapshot
        from smartcli_core.pty_backend import PosixPtyBackend
        from smartcli_core.readiness import wait_for_regex
        path = Path(smartcli_core.__file__).resolve()
        if not path.is_relative_to(root / 'smartcli_core'):
            raise RuntimeError('refusing installed package shadowing the selected checkout')
        report['import_origin'] = str(path)
        report['dependencies'] = {name: importlib.metadata.version(name) for name in ('pyte', 'wcwidth')}
    except Exception as exc:
        report['status'] = 'NOT_RUN'
        report['reason'] = f'{type(exc).__name__}: {exc}'
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 3

    def case(name, fn):
        try:
            result = fn()
            report['cases'].append({'id': name, **result})
        except Exception as exc:
            report['cases'].append({'id': name, 'status': 'PROBE_ERROR',
                                    'detail': f'{type(exc).__name__}: {exc}',
                                    'note': 'May be interface drift; inspect before calling this a product regression.'})

    def partial_write():
        backend = PosixPtyBackend()
        backend._fd = 987654  # not a real descriptor; os.write is replaced below
        accepted = bytearray(); calls = []
        def writer(fd, data):
            raw = bytes(data)
            n = min(3, len(raw))
            calls.append({'requested': len(raw), 'accepted': n})
            accepted.extend(raw[:n])
            return n
        with patch('os.write', side_effect=writer):
            backend.write(b'abcdefgh')
        backend._fd = None
        return {'status': 'PASS' if accepted == b'abcdefgh' else 'FAIL',
                'accepted_hex': accepted.hex(), 'expected_hex': b'abcdefgh'.hex(), 'calls': calls,
                'assertion': 'write contract must accept all bytes or explicitly report incomplete; this probe exercises a returning short write.'}

    def model_state(m):
        return {'cells': [[list(c) for c in m.row_cells(y)] for y in range(m.rows)],
                'cursor': list(m.cursor), 'display': m.display}

    def partition_invariance():
        sequences = [b'\x1b[4:3mX\x1b[0m', b'\x1b[38:2::255:0:0mR\x1b[0m']
        mismatches = []; checked = 0
        for seq in sequences:
            full = ScreenModel(30, 2); full.feed(seq); expected = model_state(full)
            for cut in range(1, len(seq)):
                m = ScreenModel(30, 2); m.feed(seq[:cut]); m.feed(seq[cut:]); checked += 1
                if model_state(m) != expected:
                    mismatches.append({'sequence_hex': seq.hex(), 'cut': cut,
                                       'whole_display': full.display, 'split_display': m.display})
        return {'status': 'FAIL' if mismatches else 'PASS', 'partitions_checked': checked,
                'mismatches': mismatches, 'assertion': 'same bytes, different read partitions, same state; no claim about normative SGR styling.'}

    def cjk_span():
        m = ScreenModel(20, 3)
        m.feed('中文 \x1b[7mOK\x1b[0m'.encode())
        snap = build_snapshot(m)
        spans = [{'row': s.row, 'start': s.col_start, 'end': s.col_end, 'text': s.text} for s in snap.menu_items]
        matches = [s for s in spans if s['row'] == 0 and s['start'] == 5 and s['end'] == 7]
        good = bool(matches) and matches[0]['text'] == 'OK'
        return {'status': 'PASS' if good else 'FAIL', 'spans': spans,
                'expected': {'row': 0, 'start': 5, 'end': 7, 'text': 'OK'},
                'assertion': 'cell coordinates must not be used as Unicode string indices.'}

    def ascii_control():
        m = ScreenModel(20, 3); m.feed(b'abc \x1b[7mOK\x1b[0m')
        snap = build_snapshot(m)
        found = any(s.row == 0 and s.col_start == 4 and s.text == 'OK' for s in snap.menu_items)
        return {'status': 'PASS' if found else 'FAIL', 'assertion': 'ASCII negative/control case for span probe.'}

    def widest_diagnostic():
        m = ScreenModel(30, 4)
        m.feed(b'\x1b[1mA very long decorative heading\x1b[0m\r\n\x1b[7mOK\x1b[0m')
        snap = build_snapshot(m)
        return {'status': 'OBSERVATION', 'selected_text': getattr(snap.selected, 'text', None),
                'selected_reason': snap.selected_reason,
                'note': 'Do not infer true focus from styling; this fixture does not publish widget semantics.'}

    def stale_prompt_diagnostic():
        matched, snap = wait_for_regex(lambda: b'', lambda: '>>> ', lambda: {'painted_before_action': True},
                                       r'>>> ', timeout_ms=0)
        return {'status': 'OBSERVATION', 'matched': matched, 'snapshot': snap,
                'note': 'State predicate, not application ACK. Existing-match success may be correct; do not redefine all waits as edge-triggered.'}

    case('C01-short-write', partial_write)
    case('C02-sgr-partitions', partition_invariance)
    case('C03-cjk-span', cjk_span)
    case('C04-ascii-control', ascii_control)
    case('C05-selection-diagnostic', widest_diagnostic)
    case('C06-old-prompt-contract', stale_prompt_diagnostic)
    bad = any(c['status'] in {'FAIL', 'PROBE_ERROR'} for c in report['cases'])
    report['status'] = 'FAIL' if bad else 'PASS'
    report['note'] = 'Passing these probes is not equivalent to passing the project suite or any real PTY test.'
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 1 if bad else 0

if __name__ == '__main__':
    raise SystemExit(main())
