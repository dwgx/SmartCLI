---
name: smartcli-evolution
description: Evidence-gated local improvement of dwgx/SmartCLI, with repository onboarding, focused regression work, bounded validation and resumable handoff. Use when asked to develop SmartCLI; this skill does not authorize heavy PTY runs or remote writes.
---

Read the plan kit START_HERE.md and LOCAL_AGENT_PROMPT.md. Read the target's current AGENTS/CLAUDE instructions first; do not replace them with this skill.

Use tools/agentctl.py for static inventory, run state, reviewed light gates, evidence and resumption. The tool is not an LLM or sandbox, and does not implement SmartCLI changes for you. Implement with your own local editor/tooling within the user's scope.

One real PTY at a time; heavy suites require separate approval. No automatic commit/push/release/global config changes. Preserve Python/ConPTY/POSIX default paths and vendor parity. Treat audit claims and competitor descriptions as hypotheses until checked.

Choose a small failing case, compare alternatives, implement, run focused positive/negative gates, accurately label unrun scope, then record a handoff. You may re-plan and propose bounded X- experiments with evidence; do not lower acceptance or conceal failures.

If this skill is copied alone, it is incomplete: retain the surrounding plan kit and record its local path. No global installation is performed by this bundle.
