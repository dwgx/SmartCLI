# SmartCLI 下一位工程师 / Agent 交接

## 任务

把SmartCLI升级成更可信的Agent终端交互运行时。先修已定位的数据/调度问题，再做明确的协议与证据链；不要把这份研究当作已经实现的功能。用户授权的是这次只读审查和计划，不是让你自动推送/发布。

**审计基线：** `701e61f6d69aa2420617edf80b1136df8d5e8cf7`，审查日2026-09-15，树内0.2.3。开始前读取实际HEAD并核对变更；若HEAD前进，重新验证相关函数，别把老发现不加判断地全部套上。只读audit仓库链接见data/sources.json。

## 第一轮执行顺序

1. 阅读README_FIRST、02_CODE_AUDIT的A01–A06与仓库当前HANDOFF/NEXT-STEPS；核对环境与所有者约束。不要读/重新发布已排除资料。
2. T01建立真实基线：记录解释器/依赖/OS/TERM/commit，跑现有适用门禁，保留初次失败与skip。不得写“历史44/44所以现在没问题”。
3. 将`tests/test_audit_regressions.py`放到测试环境或直接用PYTHONPATH执行；本包没有实际运行它。三个测试应在原baseline揭示问题；如没有失败，先解释依赖/代码差异而不是硬改。
4. T03短写、T04SGR分片、T05cell span分别最小修复与PR；保持可回滚；然后T08限额、T07/T09/T10调度闭环。
5. 更新canonical core后同步独立skill vendor，执行已有anti-drift门禁、native smoke与安装后MCP。以实际结果更新backlog，不能自动把所有计划项标为完成。

## 不可误读

- 本包的5项L结果只运行提取逻辑，不是完整产品基准。跨产品评分是覆盖面，不能据此写“SmartCLI快于X”。
- 已存在MCP、CLI、Python、ConPTY、视觉hash、SS3、alt screen、PNG辅助工具、Harbor适配与CI；不要重复建。
- 多watcher可共享同一屏幕，模型仍只有一个owner；不要给PtySession加并发调用。
- seq证明顺序，不证明应用接受；通用PTY返回written/observed，app ACK才可称applied，外部assert才是verified。
- 正确引擎状态不等于真实终端所有profile一致；不把IL/DL有意差异机械upstream。
- close超时不代表daemon死，不能删活registry；同UID不是可靠隔离。
- 不要默认重启用户已关闭的Dependabot版本PR；不修改main/publish权限，除非用户明确要求。

## 输入文件与预期产物

`data/backlog.json`有38个独立任务；`data/audit_findings.json`有20发现；`docs/03_COMPETITOR_TRANSFER.md`指向要读的竞品文件而非模糊项目名；`contracts`是建议schema，只能在明确迁移后采用。

每项工程交付应包含：改动SHA/分支、修复前后repro、测试/环境、未覆盖项、性能影响（若测过）、兼容变更、vendor/version/doc同步、rollback。不可拿截图替代业务断言，不可把任务最终文件写对当作严格UI赛道成功。

## 复现器说明

`python tests/reproduce_extracted_logic.py`是安全、本地、无依赖的5个逻辑反例，已运行结果见evidence。它用于讲清缺陷而非验证修复；真正修复必须运行直接导入产品的regression与真实目标程序。

## 完成判据

第一阶段收尾＝A01–A06有结果、相关回归与适用native smoke通过、无未解释的活进程/输入缺失/视觉失真，所有限制写清。再依赖图推进G3/G4，不因“功能看起来够多”跳过可靠性。
