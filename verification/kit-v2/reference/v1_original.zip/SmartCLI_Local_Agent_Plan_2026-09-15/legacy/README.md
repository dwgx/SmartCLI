# Historical input, not current truth
These files are copied from the previous audit package. Do not mark tasks complete from their prose.
The full prior ZIP remains a separate user artifact; this bundle keeps only the relevant machine-readable records and handoff.
New research corrections and local execution rules are in this kit's docs and new_sources.json.
Old static scoring is NOT promoted into a benchmark or into local runtime evidence.
