# ADR: <decision>
Status: proposed / accepted / superseded / rejected

Context and current code evidence:
Problem invariant (not implementation preference):
Options A/B/C, migration cost and constraints:
Chosen minimal experiment:
Measurement and counterexample:
Result and uncertainties:
Decision, rollback and what would change this decision:
Affected task IDs and public compatibility:
Source/license provenance (verify before code reuse):
Reviewer and method (self-review is not independent):
