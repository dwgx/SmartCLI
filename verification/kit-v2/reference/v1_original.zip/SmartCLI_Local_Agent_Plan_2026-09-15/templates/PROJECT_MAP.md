# SmartCLI project map — local agent fills this BEFORE execution

## 1. Actual checkout and user constraints
[TODO] Record HEAD, dirty paths, interpreter, platform, instruction files read; never expose credential values. Explain single-PTY / heavy-test consent / no-auto-commit constraints.

## 2. End-to-end call path
[TODO] Identify real file:symbol references for MCP or CLI request → daemon → PtySession → backend → screen parser → snapshot → wait → response. AST output alone is not a resolved call graph.

## 3. State and ownership
[TODO] Who owns raw bytes, pyte mutation, dirty rows, write queue, process status, registry token, observer state? Name blocking boundaries.

## 4. Existing assets to preserve
[TODO] Locate SS3 mode adaptation, alternate screen, device replies, text/visual hash, vendor sync, screenshot and smoke tools. Do not reinvent them.

## 5. Audit claims revalidation
[TODO] Classify A01–A06 on actual code: reproduced / source-supported / contradicted / not tested. Distinguish source claim from real PTY evidence.

## 6. First coherent patch and alternatives
[TODO] Choose one small task, regression first, acceptance checks, rejected alternative, rollback, and stop rule. Source edits are local; no commit/push/release.

## 7. Unknowns
[TODO] Missing platform, dependency or instruction context must remain unknown, not assumed success.
