# Upstream mechanism review
Repository, commit, blob/file and line range:
License/provenance checked (not inferred from language):
Advertised claim:
Actual call path including fallback, cancellation and error handling:
What was executed versus only read:
Negative case / counterexample:
What transfers to SmartCLI:
What MUST NOT transfer:
Minimum local experiment and gate:
