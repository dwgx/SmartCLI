# Local session closeout
Actual HEAD and dirty paths:
Completed tasks and evidence filenames:
First-attempt failures / skip / not-run:
Current hypotheses and rejected approaches:
Owned PTY / process handles and cleanup outcome:
Unresolved approvals (no credentials):
Next single task, exact relevant files, acceptance and stop rule:
No commit/push/release performed unless separately authorized:
