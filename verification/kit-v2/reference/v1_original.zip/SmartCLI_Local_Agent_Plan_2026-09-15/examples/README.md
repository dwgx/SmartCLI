# Proposed contract examples — NOT current SmartCLI API
These JSON objects illustrate target semantics. They are not accepted by SmartCLI 0.2.3 and are not a generated patch.
The workbench does not submit them to any daemon. Local agents may replace them after an ADR and compatibility tests.
Sequence fields are decimal strings to avoid consumer integer precision ambiguity. A revision correlates states; it does not prove an input caused a change.
