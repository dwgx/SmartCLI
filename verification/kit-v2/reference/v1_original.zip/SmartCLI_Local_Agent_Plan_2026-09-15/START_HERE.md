# SmartCLI · 本地 Agent 执行入口

这是交给本地编码 Agent 的计划与工作台，不是 SmartCLI 新版本，也不是会自行调用模型的 Agent。
把整个目录放到 SmartCLI 仓库旁边；不要覆盖仓库已有 AGENTS.md / CLAUDE.md / Skill。

## 给本地 Agent 的一句话

> 阅读本目录 LOCAL_AGENT_PROMPT.md；目标是旁边的 dwgx/SmartCLI 工作区。先理解当前项目与本机约束，建立事实基线；随后按 MASTER_PLAN.md 选择最小高价值任务，先复现再实现、验证并留下可续接证据。你可以提出和验证更好的方案，不必照抄架构草案。不得自动 commit、push、发布、上传日志或跑未经单独批准的重型 PTY 套件。

## 最小启动（Windows / macOS / Linux）

以下从本计划包根目录运行，REPO 和 RUN 替换成本机绝对路径。RUN 必须在 SmartCLI 仓库和计划包之外。Windows 可用 `py -3` 替代 `python`。

```bash
python tools/agentctl.py verify-kit
python tools/agentctl.py --repo "/path/to/SmartCLI" doctor
python tools/agentctl.py --repo "/path/to/SmartCLI" --run "/path/to/smartcli-local-run" init
```

这些命令不安装依赖、不导入 SmartCLI、不运行测试、不修改目标代码。doctor 调用有时间上限的 Git 只读查询，输出本地路径、文件名与指纹；不要把其输出当作可公开上传的材料。

然后由 Agent 阅读目标仓库指令及 `docs/01_REPOSITORY_TOUR.md`，填写 RUN/PROJECT_MAP.md，解释实际调用链、线程所有权、兼容性、未核实项和第一项修改，再执行：

```bash
python tools/agentctl.py --repo "/path/to/SmartCLI" --run "/path/to/smartcli-local-run" acknowledge
python tools/agentctl.py --repo "/path/to/SmartCLI" --run "/path/to/smartcli-local-run" next
```

acknowledge 只是记录 Agent 已填写地图，不证明它真的理解。所有源码执行仍需单独的显式参数。

## 第一个代码验证入口

先审查工具脚本和目标模块，选好已有 pyte 的项目虚拟环境。不要为了省一步全局安装或自动升级依赖。

```bash
python tools/agentctl.py --repo "/path/to/SmartCLI" --run "/path/to/smartcli-local-run" probe --python "/path/to/venv/bin/python" --execute-reviewed-code
```

Windows 的 `--python` 用虚拟环境内 `Scripts/python.exe`。probe 实际导入本地 core；检查短写替身、SGR 分片、CJK span 和 ASCII 对照，另输出选中项及旧提示符诊断。它不 spawn PTY。缺依赖会 NOT_RUN，不会 PASS。

工具自身用标准库即可运行。目标代码、目标测试的依赖仍由目标项目决定。`--execute-reviewed-code` 不是安全沙箱；执行已审查的 Python 仍具有当前用户权限。

## 阅读顺序

先 LOCAL_AGENT_PROMPT → MASTER_PLAN → REPOSITORY_TOUR → RESEARCH_DELTA。之后按任务查 docs/ARCHITECTURE、ACCEPTANCE、AUTONOMY 和 TASK_CARDS；不要把全部历史文档一口气塞入模型上下文。

恢复工作时读 RUN/RESUME.md、state.json 和最新证据，再核对当前 HEAD。`legacy/` 只是上轮历史输入，不能优先于真实代码和本机验证。
