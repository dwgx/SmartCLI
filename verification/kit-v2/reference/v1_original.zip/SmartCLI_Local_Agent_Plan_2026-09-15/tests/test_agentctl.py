"""Workbench tests: temporary fixtures only; never starts a SmartCLI PTY."""
from __future__ import annotations
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest

KIT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('agentctl', KIT/'tools/agentctl.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)

class WorkbenchTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.repo = self.base/'repo'; self.repo.mkdir()
        (self.repo/'smartcli_core').mkdir()
        (self.repo/'pyproject.toml').write_text('[project]\nname="smartcli-toolkit"\n',encoding='utf-8')
        (self.repo/'smartcli_core/__init__.py').write_text('raise RuntimeError("must not import during inventory")\n',encoding='utf-8')
        (self.repo/'smartcli_core/example.py').write_text('import os\nclass Sample:\n    def read(self):\n        return 1\n',encoding='utf-8')
        self.run=self.base/'run'
    def tearDown(self): self.tmp.cleanup()
    def invoke(self,*args):
        out=io.StringIO(); err=io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            rc=a.main(['--repo',str(self.repo),'--run',str(self.run),*args])
        return rc,out.getvalue(),err.getvalue()
    def init(self):
        rc,_,e=self.invoke('init'); self.assertEqual(rc,0,e)
    def test_inventory_never_imports(self):
        inv=a.inventory(self.repo)
        self.assertIn('smartcli_core/__init__.py',inv['files'])
    def test_symbols_have_line_spans(self):
        e=a.inventory(self.repo)['files']['smartcli_core/example.py']
        self.assertEqual({v['name'] for v in e['symbols']},{'Sample','read'})
    def test_inventory_changes_with_code(self):
        before=a.inventory(self.repo)['fingerprint']
        (self.repo/'smartcli_core/example.py').write_text('x=2\n')
        self.assertNotEqual(before,a.inventory(self.repo)['fingerprint'])
    def test_inventory_excludes_env(self):
        (self.repo/'.env').write_text('SECRET=x')
        self.assertNotIn('.env',a.inventory(self.repo)['files'])
    def test_inventory_is_bounded(self):
        (self.repo/'smartcli_core/big.py').write_bytes(b'x'*(a.MAX_FILE+1))
        inv=a.inventory(self.repo)
        self.assertTrue(inv['warnings']); self.assertNotIn('smartcli_core/big.py',inv['files'])
    def test_parse_error_is_reported(self):
        (self.repo/'smartcli_core/broken.py').write_text('def :')
        self.assertEqual(a.inventory(self.repo)['files']['smartcli_core/broken.py']['ast_error'],'SyntaxError')
    def test_outside_path_rejected(self):
        with self.assertRaises(ValueError): a.contained(self.repo,'../anything')
    def test_absolute_path_rejected(self):
        with self.assertRaises(ValueError): a.contained(self.repo,str(self.repo/'pyproject.toml'))
    def test_backslash_path_rejected(self):
        with self.assertRaises(ValueError): a.contained(self.repo,'..\\outside')
    @unittest.skipUnless(hasattr(os,'symlink'),'requires symlink support')
    def test_symlink_rejected(self):
        try: (self.repo/'link.md').symlink_to(self.repo/'pyproject.toml')
        except OSError: self.skipTest('symlinks not permitted by this OS account')
        with self.assertRaises(ValueError): a.contained(self.repo,'link.md')
    def test_run_inside_repo_rejected(self):
        with self.assertRaises(ValueError): a.run_root(str(self.repo/'out'),self.repo)
    def test_invalid_repo_rejected(self):
        with self.assertRaises(ValueError): a.repo_root(str(self.base))
    def test_dag_cycle_rejected(self):
        with self.assertRaises(ValueError): a.validate_dag([{'id':'a','dependencies':['b']},{'id':'b','dependencies':['a']}])
    def test_dag_unknown_dependency_rejected(self):
        with self.assertRaises(ValueError): a.validate_dag([{'id':'a','dependencies':['z']}])
    def test_dag_duplicate_rejected(self):
        with self.assertRaises(ValueError): a.validate_dag([{'id':'a'},{'id':'a'}])
    def test_ready_respects_dependencies(self):
        tasks=[{'id':'a','priority':'P0','dependencies':[]},{'id':'b','priority':'P1','dependencies':['a']}]
        state={'tasks':{'a':{'status':'pending'},'b':{'status':'pending'}}}
        self.assertEqual([t['id'] for t in a.ready_tasks(tasks,state)],['a'])
        state['tasks']['a']['status']='verified'
        self.assertEqual([t['id'] for t in a.ready_tasks(tasks,state)],['b'])
    def test_exclusive_lock(self):
        with a.lock(self.run):
            with self.assertRaises(ValueError):
                with a.lock(self.run): pass
        self.assertFalse((self.run/'.agentctl.lock').exists())
    def test_atomic_json(self):
        a.write_json(self.base/'a.json',{'value':'中文'})
        self.assertEqual(a.load_json(self.base/'a.json')['value'],'中文')
    def test_init_creates_only_output(self):
        fp=a.inventory(self.repo)['fingerprint']; self.init()
        self.assertEqual(fp,a.inventory(self.repo)['fingerprint'])
        self.assertTrue((self.run/'PROJECT_MAP.md').exists())
    def test_init_never_resets_state(self):
        self.init(); rc,_,_=self.invoke('init'); self.assertEqual(rc,2)
    def test_ack_requires_completed_map(self):
        self.init(); rc,_,_=self.invoke('acknowledge'); self.assertEqual(rc,2)
    def test_ack_then_handoff(self):
        self.init()
        (self.run/'PROJECT_MAP.md').write_text('# Map\n'+('Observed source symbol and unresolved boundary.\n'*30))
        rc,_,e=self.invoke('acknowledge'); self.assertEqual(rc,0,e)
        rc,_,e=self.invoke('handoff'); self.assertEqual(rc,0,e)
        self.assertTrue((self.run/'RESUME.md').is_file())
    def test_execution_requires_explicit_flag(self):
        self.init()
        (self.run/'PROJECT_MAP.md').write_text('source map\n'*100)
        self.invoke('acknowledge')
        rc,_,e=self.invoke('probe'); self.assertEqual(rc,2); self.assertIn('opt-in',e)
    def test_pty_gate_refused_even_after_opt_in(self):
        self.init(); (self.run/'PROJECT_MAP.md').write_text('source map\n'*100); self.invoke('acknowledge')
        rc,_,e=self.invoke('gate','--id','cli-pty','--execute-reviewed-code')
        self.assertEqual(rc,2); self.assertIn('refuses PTY',e)
    def test_unknown_gate_refused(self):
        self.init(); (self.run/'PROJECT_MAP.md').write_text('source map\n'*100); self.invoke('acknowledge')
        rc,_,_=self.invoke('gate','--id','nope','--execute-reviewed-code'); self.assertEqual(rc,2)
    def test_bounded_run_exit_status(self):
        r=a.bounded_run([sys.executable,'-c','print("ok"); raise SystemExit(7)'],self.base,self.base/'fail.log',3)
        self.assertEqual(r['returncode'],7); self.assertEqual(r['status'],'FAIL')
    def test_bounded_run_timeout(self):
        r=a.bounded_run([sys.executable,'-c','import time;time.sleep(5)'],self.base,self.base/'slow.log',.15)
        self.assertEqual(r['status'],'TIMEOUT')
    def test_bounded_run_skip_not_pass(self):
        r=a.bounded_run([sys.executable,'-c','print("SKIP: missing optional dependency")'],self.base,self.base/'skip.log',3)
        self.assertEqual(r['status'],'PASS_WITH_SKIP')
    def test_bounded_run_output_limit(self):
        r=a.bounded_run([sys.executable,'-c','print("x"*200000)'],self.base,self.base/'large.log',3,max_log=1000)
        self.assertEqual(r['status'],'OUTPUT_LIMIT'); self.assertLessEqual((self.base/'large.log').stat().st_size,1000)
    def test_environment_omits_arbitrary_secret(self):
        from unittest.mock import patch
        with patch.dict(os.environ,{'OPENAI_API_KEY':'never-log','PRIVATE_TOKEN':'no'}):
            env=a.child_environment(self.repo,self.run)
        self.assertNotIn('OPENAI_API_KEY',env); self.assertNotIn('PRIVATE_TOKEN',env)
    def test_closure_requires_evidence(self):
        self.run.mkdir(); doc={'task_id':'T01','status':'verified','summary':'a'*40,'source_fingerprint':'x','acceptance_checks':['checked'],'evidence':[],'review':{'method':'self'}}
        with self.assertRaises(ValueError): a.closure_check(doc,self.run,'verified','x')
    def test_closure_rejects_stale_fingerprint(self):
        self.run.mkdir(); (self.run/'log.md').write_text('proof')
        doc={'task_id':'T01','status':'verified','summary':'a'*40,'source_fingerprint':'old','acceptance_checks':['checked'],'evidence':['log.md'],'review':{'method':'self'}}
        with self.assertRaises(ValueError): a.closure_check(doc,self.run,'verified','new')
    def test_proposal_adds_without_overwriting(self):
        self.init(); (self.run/'evidence/research.md').write_text('Hypothesis and source audit')
        a.write_json(self.run/'experiment.json',{'id':'X-try','title':'experiment','priority':'P2','dependencies':['T01'],'hypothesis':'test','acceptance':'test','stop_rule':'bounded','evidence':['evidence/research.md']})
        rc,_,e=self.invoke('propose','--spec','experiment.json'); self.assertEqual(rc,0,e)
        self.assertIn('X-try',a.load_json(self.run/'state.json')['tasks'])
    def test_tool_does_not_accept_arbitrary_command(self):
        p=Path(a.__file__).read_text()
        self.assertNotIn('shell=True',p)
    def test_start_failure_is_evidence_not_success(self):
        r=a.bounded_run([str(self.base/'does-not-exist')],self.base,self.base/'start.log',3)
        self.assertEqual(r['status'],'START_FAILED')
        self.assertIsNone(r['returncode'])
    def test_failed_acceptance_cannot_close(self):
        self.run.mkdir(); (self.run/'log.md').write_text('evidence')
        doc={'task_id':'T01','status':'verified','summary':'a'*40,'source_fingerprint':'x',
             'acceptance_checks':[{'name':'test','scope':'memory','result':'fail'}],
             'evidence':['log.md'],'review':{'method':'self'}}
        with self.assertRaises(ValueError):a.closure_check(doc,self.run,'verified','x')
    def test_task_graph(self): a.validate_dag(a.all_tasks())

if __name__=='__main__': unittest.main(verbosity=2)
