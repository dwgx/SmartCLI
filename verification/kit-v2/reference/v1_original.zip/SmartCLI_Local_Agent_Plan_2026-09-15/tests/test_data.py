"""Data/contract tests for the delivery, not SmartCLI product tests."""
import json
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
def read(rel):return json.loads((ROOT/rel).read_text(encoding='utf-8'))
class DeliveryDataTests(unittest.TestCase):
    def test_fifty_unique_tasks(self):
        ids=[t['id'] for t in read('data/tasks.json')]
        self.assertEqual(len(ids),50); self.assertEqual(len(set(ids)),50)
    def test_all_task_sources_resolve(self):
        ids={s['id'] for s in read('legacy/sources.json')+read('data/new_sources.json')}
        for t in read('data/tasks.json'):
            self.assertTrue(set(t['sources'])<=ids,t['id'])
    def test_milestones_cover_all_tasks(self):
        m=[t for r in read('data/milestones.json') for t in r['tasks']]
        self.assertEqual(set(m),{t['id'] for t in read('data/tasks.json')})
        self.assertEqual(len(m),50)
    def test_benchmarks_are_not_claimed_implemented(self):
        b=read('data/benchmarks.json');self.assertEqual(len(b),32)
        for x in b:self.assertIn('not an implemented',x['implementation_status'])
    def test_proposed_observation_cell_coordinates(self):
        x=read('examples/observation.proposed.json')
        self.assertTrue(x['schema'].startswith('draft'))
        self.assertEqual(x['inferences']['selected'],None)
        self.assertEqual(x['inferences']['selected_candidates'][0]['start_col'],5)
    def test_partial_input_not_verified(self):
        x=read('examples/input.partial.proposed.json')
        self.assertLess(x['bytes']['written'],x['bytes']['requested'])
        self.assertEqual(x['verification']['status'],'not_evaluated')
    def test_cancel_wait_does_not_destroy_session(self):
        x=read('examples/wait.cancelled.proposed.json')
        self.assertFalse(x['condition_satisfied']);self.assertFalse(x['session_destroyed'])
    def test_workbench_not_a_coding_agent(self):
        x=read('config/workbench_contract.json')
        self.assertIn('automatic source editing',x['not_implemented'])
        self.assertFalse(x['defaults']['pty_gate_execution'])
    def test_expected_documents_exist(self):
        for name in ['START_HERE.md','LOCAL_AGENT_PROMPT.md','MASTER_PLAN.md','docs/01_REPOSITORY_TOUR.md','docs/02_RESEARCH_DELTA.md','docs/03_EXECUTION_MODEL.md','docs/04_ARCHITECTURE.md','docs/05_ACCEPTANCE.md','docs/06_TASK_CARDS.md','docs/07_AUTONOMY.md','docs/08_MIGRATION.md','docs/09_BENCHMARKS.md','docs/10_SECURITY.md','docs/11_TOOL_MANUAL.md','docs/12_SOURCES.md']:
            self.assertGreater((ROOT/name).stat().st_size,100,name)
    def test_all_tasks_pending(self):
        for t in read('data/tasks.json'):self.assertEqual(t['status'],'pending')
if __name__=='__main__':unittest.main(verbosity=2)
